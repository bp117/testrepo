"""Core of hartford-cli: working-tree checkpoints and authorship notes.

How it works
------------
1. Agent hooks call `hartford checkpoint` before and after every tool use.
   A checkpoint diffs each dirty file against the previous checkpoint and
   tags the lines that changed: with the agent session after a tool ran,
   with nothing (human or unknown) before it ran.
2. The post-commit git hook condenses those tags into an authorship log for
   the lines the commit added and attaches it as a git note on refs/notes/ai,
   in the Git AI Standard v3.0.0 format.
3. The post-rewrite hook carries logs across amend and rebase by aligning the
   old and new file contents.

State lives in <git-dir>/hartford/working.json and is never committed.
Only the standard library is used.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import os
import re
import secrets
import subprocess
from pathlib import Path

NOTES_REF = "refs/notes/ai"
SCHEMA_VERSION = "authorship/3.0.0"
MAX_FILE_BYTES = 2_000_000
_HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
_BLAME_HEAD = re.compile(r"^([0-9a-f]{40}) (\d+) (\d+)")


class GitError(RuntimeError):
    pass


# --------------------------------------------------------------------- git

def git(*args: str, cwd: str | None = None, check: bool = True,
        stdin: bytes | None = None, env: dict | None = None, timeout: float | None = None) -> str:
    proc = subprocess.run(["git", "-c", "core.quotepath=off", *args], cwd=cwd, input=stdin,
                          capture_output=True, env=env, timeout=timeout)
    if check and proc.returncode != 0:
        raise GitError(proc.stderr.decode(errors="replace").strip() or f"git {args[0]} failed")
    return proc.stdout.decode("utf-8", errors="surrogateescape")


def repo_root(cwd: str | None = None) -> str | None:
    out = git("rev-parse", "--show-toplevel", cwd=cwd, check=False).strip()
    return out or None


def git_dir(root: str) -> Path:
    p = Path(git("rev-parse", "--git-dir", cwd=root).strip())
    return p if p.is_absolute() else Path(root) / p


def head_sha(root: str) -> str | None:
    return git("rev-parse", "--verify", "--quiet", "HEAD", cwd=root, check=False).strip() or None


def split_lines(text: str) -> list[str]:
    """Split the way git counts lines (on \\n only)."""
    if not text:
        return []
    lines = text.split("\n")
    if lines[-1] == "":
        lines.pop()
    return lines


def file_at(root: str, rev: str, path: str) -> list[str] | None:
    """Lines of a file at a revision, or None when absent or binary."""
    proc = subprocess.run(["git", "show", f"{rev}:{path}"], cwd=root, capture_output=True)
    if proc.returncode != 0 or b"\0" in proc.stdout[:8000]:
        return None
    return split_lines(proc.stdout.decode("utf-8", errors="surrogateescape"))


def working_file(root: str, path: str) -> list[str] | None:
    """Lines of a working-tree file, or None when missing, binary or too large."""
    full = Path(root) / path
    try:
        if not full.is_file() or full.stat().st_size > MAX_FILE_BYTES:
            return None
        data = full.read_bytes()
    except OSError:
        return None
    if b"\0" in data[:8000]:
        return None
    return split_lines(data.decode("utf-8", errors="surrogateescape"))


def dirty_files(root: str) -> list[str]:
    """Paths that differ from HEAD: modified, added or untracked (not ignored)."""
    out = git("status", "--porcelain=v1", "-z", "--untracked-files=all", cwd=root)
    parts = out.split("\0")
    paths, i = [], 0
    while i < len(parts):
        entry = parts[i]
        i += 1
        if len(entry) < 4:
            continue
        status, path = entry[:2], entry[3:]
        if status[0] in "RC":
            i += 1  # skip the rename/copy source that follows
        if "D" in status and not (Path(root) / path).exists():
            continue
        paths.append(path)
    return paths


def added_lines(root: str, sha: str) -> tuple[dict[str, list[tuple[int, int]]], int]:
    """Lines a commit added as {file: [(start, end)]}, plus its deleted-line count."""
    out = git("show", "--format=", "--unified=0", "--no-color", "--no-ext-diff",
              "--first-parent", sha, cwd=root)
    added: dict[str, list[tuple[int, int]]] = {}
    deleted = 0
    current = None
    for line in out.split("\n"):
        if line.startswith("+++ "):
            target = line[4:].rstrip("\t")
            current = target[2:] if target.startswith("b/") else None
        elif line.startswith("@@") and current is not None:
            m = _HUNK.match(line)
            if not m:
                continue
            deleted += int(m.group(2)) if m.group(2) is not None else 1
            count = int(m.group(4)) if m.group(4) is not None else 1
            if count:
                start = int(m.group(3))
                added.setdefault(current, []).append((start, start + count - 1))
    return added, deleted


def read_note(root: str, sha: str) -> str | None:
    out = git("notes", f"--ref={NOTES_REF}", "show", sha, cwd=root, check=False)
    return out or None


def write_note(root: str, sha: str, text: str) -> None:
    git("notes", f"--ref={NOTES_REF}", "add", "-f", "-F", "-", sha, cwd=root, stdin=text.encode())


# ------------------------------------------------------------ note format

def parse_ranges(spec: str) -> list[tuple[int, int]]:
    out = []
    for part in spec.split(","):
        try:
            if "-" in part:
                a, b = part.split("-", 1)
                s, e = int(a), int(b)
            else:
                s = e = int(part)
        except ValueError:
            continue
        if 1 <= s <= e:
            out.append((s, e))
    return out


def parse_note(text: str) -> tuple[dict[str, dict[int, str]], dict]:
    """-> ({file: {line: attestation key}}, metadata dict). Never raises."""
    lines = text.split("\n")
    try:
        divider = lines.index("---")
    except ValueError:
        divider = len(lines)
    meta: dict = {}
    try:
        loaded = json.loads("\n".join(lines[divider + 1:]) or "{}")
        if isinstance(loaded, dict):
            meta = loaded
    except json.JSONDecodeError:
        pass
    files: dict[str, dict[int, str]] = {}
    current = None
    for line in lines[:divider]:
        if not line.strip():
            continue
        if line.startswith("  "):
            if current is None:
                continue
            key, _, spec = line.strip().partition(" ")
            for s, e in parse_ranges(spec):
                for n in range(s, e + 1):
                    files[current].setdefault(n, key)
        else:
            path = line.strip()
            if len(path) >= 2 and path[0] == '"' and path[-1] == '"':
                path = path[1:-1]
            current = path
            files.setdefault(current, {})
    return files, meta


def _compress(nums: list[int]) -> str:
    parts, start, prev = [], None, None
    for n in sorted(nums):
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            parts.append(str(start) if start == prev else f"{start}-{prev}")
            start = prev = n
    if start is not None:
        parts.append(str(start) if start == prev else f"{start}-{prev}")
    return ",".join(parts)


def render_note(sha: str, files: dict[str, dict[int, str]], sessions: dict,
                humans: dict | None = None, prompts: dict | None = None) -> str:
    out = []
    used: set[str] = set()
    for path in sorted(files):
        by_key: dict[str, list[int]] = {}
        for line, key in files[path].items():
            by_key.setdefault(key, []).append(line)
        if not by_key:
            continue
        out.append(f'"{path}"' if re.search(r"\s", path) else path)
        for key in sorted(by_key, key=lambda k: min(by_key[k])):
            out.append(f"  {key} {_compress(by_key[key])}")
            used.add(key.split("::", 1)[0])
    meta = {
        "schema_version": SCHEMA_VERSION,
        "base_commit_sha": sha,
        "prompts": {k: v for k, v in (prompts or {}).items() if k in used},
        "humans": {k: v for k, v in (humans or {}).items() if k in used},
        "sessions": {k: v for k, v in sessions.items() if k in used},
    }
    return "\n".join(out + ["---", json.dumps(meta, indent=2)]) + "\n"


def session_id(tool: str, conversation_id: str) -> str:
    return "s_" + hashlib.sha256(f"{tool}:{conversation_id}".encode()).hexdigest()[:14]


def trace_id() -> str:
    return "t_" + secrets.token_hex(7)


def resolve_key(key: str, meta: dict) -> tuple[str, str, str]:
    """-> (kind, tool, model) where kind is 'ai' or 'human'."""
    if key.startswith("h_"):
        return "human", "", ""
    if key.startswith("s_"):
        rec = (meta.get("sessions") or {}).get(key.split("::", 1)[0]) or {}
    else:
        rec = (meta.get("prompts") or {}).get(key) or {}
    agent = rec.get("agent_id") or {}
    return "ai", str(agent.get("tool") or "unknown"), str(agent.get("model") or "unknown")


# ------------------------------------------------------------ working log

def _state_path(root: str) -> Path:
    return git_dir(root) / "hartford" / "working.json"


def load_state(root: str) -> dict:
    try:
        state = json.loads(_state_path(root).read_text(encoding="utf-8", errors="surrogateescape"))
    except (OSError, json.JSONDecodeError):
        state = {}
    state.setdefault("files", {})
    state.setdefault("sessions", {})
    return state


def save_state(root: str, state: dict) -> None:
    path = _state_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(state), encoding="utf-8", errors="surrogateescape")
    os.replace(tmp, path)


def carry(old_lines: list[str], old_keys: list, new_lines: list[str], fill) -> list:
    """Keys for new_lines: unchanged lines keep their key, changed lines get `fill`."""
    if old_lines == new_lines:
        return list(old_keys)
    keys: list = []
    sm = difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            keys.extend(old_keys[i1:i2])
        elif tag in ("insert", "replace"):
            keys.extend([fill] * (j2 - j1))
    return keys


def checkpoint(root: str, key: str | None, session: tuple[str, dict] | None = None) -> dict:
    """Tag every line changed since the last checkpoint with `key`
    (None = human or unknown). Returns {file: lines tagged}."""
    state = load_state(root)
    files = state["files"]
    dirty = set(dirty_files(root))
    has_head = head_sha(root) is not None
    touched: dict[str, int] = {}

    for path in list(files):
        if path not in dirty:
            del files[path]  # reverted to HEAD, or committed

    for path in sorted(dirty):
        cur = working_file(root, path)
        if cur is None:
            files.pop(path, None)
            continue
        prev = files.get(path)
        if prev is None:
            base = (file_at(root, "HEAD", path) if has_head else None) or []
            prev = {"lines": base, "keys": [None] * len(base)}
        if prev["lines"] == cur:
            files[path] = prev
            continue
        mark = object()
        carried = carry(prev["lines"], prev["keys"], cur, mark)
        changed = sum(1 for k in carried if k is mark)
        keys = [key if k is mark else k for k in carried]
        files[path] = {"lines": cur, "keys": keys}
        if changed:
            touched[path] = changed

    if session and touched:
        state["sessions"][session[0]] = session[1]
    save_state(root, state)
    return touched


# -------------------------------------------------------------- git hooks

def in_rewrite(root: str) -> bool:
    gd = git_dir(root)
    return any((gd / d).exists() for d in ("rebase-merge", "rebase-apply"))


def post_commit(root: str) -> str | None:
    """Write the authorship log for HEAD from the working log."""
    sha = head_sha(root)
    if not sha or in_rewrite(root):
        return None
    if len(git("rev-list", "--parents", "-n", "1", sha, cwd=root).split()) > 2:
        return None  # merge commit: nothing of its own to attribute
    state = load_state(root)
    added, _ = added_lines(root, sha)
    files: dict[str, dict[int, str]] = {}
    for path, spans in added.items():
        entry = state["files"].get(path)
        if not entry:
            continue
        committed = file_at(root, sha, path)
        if committed is None:
            continue
        keys = carry(entry["lines"], entry["keys"], committed, None)
        attested = {n: keys[n - 1] for s, e in spans for n in range(s, e + 1)
                    if n <= len(keys) and keys[n - 1]}
        if attested:
            files[path] = attested
    write_note(root, sha, render_note(sha, files, state["sessions"]))

    # Drop state for files that are now clean; keep partially-committed ones.
    dirty = set(dirty_files(root))
    state["files"] = {p: v for p, v in state["files"].items() if p in dirty}
    live = {k.split("::", 1)[0] for v in state["files"].values() for k in v["keys"] if k}
    state["sessions"] = {k: v for k, v in state["sessions"].items() if k in live}
    save_state(root, state)
    return sha


def remap(root: str, new: str, olds: list[str]) -> bool:
    """Carry authorship from old commits onto a rewritten commit by aligning
    file contents. Used for amend, rebase, squash, and CI reconstruction."""
    existing = read_note(root, new)
    files, meta = parse_note(existing) if existing else ({}, {})
    sessions = dict(meta.get("sessions") or {})
    humans = dict(meta.get("humans") or {})
    prompts = dict(meta.get("prompts") or {})
    added, _ = added_lines(root, new)
    found = existing is not None

    for old in olds:
        text = read_note(root, old)
        if text is None:
            continue
        found = True
        old_files, old_meta = parse_note(text)
        sessions.update(old_meta.get("sessions") or {})
        humans.update(old_meta.get("humans") or {})
        prompts.update(old_meta.get("prompts") or {})
        for path, line_keys in old_files.items():
            if path not in added or not line_keys:
                continue
            old_lines, new_lines = file_at(root, old, path), file_at(root, new, path)
            if old_lines is None or new_lines is None:
                continue
            old_keys = [line_keys.get(n) for n in range(1, len(old_lines) + 1)]
            keys = carry(old_lines, old_keys, new_lines, None)
            target = files.setdefault(path, {})
            for s, e in added[path]:
                for n in range(s, e + 1):
                    if n <= len(keys) and keys[n - 1] and n not in target:
                        target[n] = keys[n - 1]
    if not found:
        return False
    # keep only attestations on lines the new commit really added
    for path in list(files):
        spans = added.get(path, [])
        files[path] = {n: k for n, k in files[path].items() if any(s <= n <= e for s, e in spans)}
    write_note(root, new, render_note(new, files, sessions, humans, prompts))
    return True


def post_rewrite(root: str, pairs: list[tuple[str, str]]) -> int:
    by_new: dict[str, list[str]] = {}
    for old, new in pairs:
        by_new.setdefault(new, []).append(old)
    return sum(1 for new, olds in by_new.items() if remap(root, new, olds))


# ------------------------------------------------------------------ notes sync

def sync_notes(root: str, remote: str = "origin", push: bool = True, timeout: float = 30) -> str:
    env = dict(os.environ, HARTFORD_PUSHING="1")
    tmp_ref = "refs/notes/hartford-remote"
    try:
        fetched = subprocess.run(
            ["git", "fetch", "--quiet", "--no-tags", remote, f"+{NOTES_REF}:{tmp_ref}"],
            cwd=root, capture_output=True, env=env, timeout=timeout).returncode == 0
    except subprocess.TimeoutExpired:
        return "fetch timed out"
    local = git("rev-parse", "--verify", "--quiet", NOTES_REF, cwd=root, check=False).strip()
    if fetched:
        if not local:
            git("update-ref", NOTES_REF, tmp_ref, cwd=root)
        else:
            # logs are immutable per commit, so on a clash keeping ours is safe
            git("notes", f"--ref={NOTES_REF}", "merge", "-s", "ours", "--quiet", tmp_ref,
                cwd=root, check=False)
    elif not local:
        return "no notes locally or on the remote"
    if not push:
        return "fetched" if fetched else "nothing to fetch"
    try:
        pushed = subprocess.run(["git", "push", "--quiet", "--no-verify", remote, NOTES_REF],
                                cwd=root, capture_output=True, env=env, timeout=timeout)
    except subprocess.TimeoutExpired:
        return "push timed out"
    if pushed.returncode == 0:
        return "synced"
    err = pushed.stderr.decode(errors="replace").strip().splitlines()
    return "push rejected" + (": " + err[-1] if err else "")


# ------------------------------------------------------------- reporting

def commit_stats(root: str, sha: str) -> dict:
    added, deleted = added_lines(root, sha)
    total = sum(e - s + 1 for spans in added.values() for s, e in spans)
    stats = {"human_additions": 0, "unknown_additions": 0, "ai_additions": 0, "ai_accepted": 0,
             "git_diff_deleted_lines": deleted, "git_diff_added_lines": total,
             "tool_model_breakdown": {}}
    text = read_note(root, sha)
    if text:
        files, meta = parse_note(text)
        for path, spans in added.items():
            line_keys = files.get(path) or {}
            for s, e in spans:
                for n in range(s, e + 1):
                    key = line_keys.get(n)
                    if not key:
                        continue
                    kind, tool, model = resolve_key(key, meta)
                    if kind == "human":
                        stats["human_additions"] += 1
                    else:
                        stats["ai_additions"] += 1
                        b = stats["tool_model_breakdown"].setdefault(
                            f"{tool}::{model}", {"ai_additions": 0, "ai_accepted": 0})
                        b["ai_additions"] += 1
                        b["ai_accepted"] += 1
    stats["ai_accepted"] = stats["ai_additions"]
    stats["unknown_additions"] = total - stats["ai_additions"] - stats["human_additions"]
    return stats


def range_stats(root: str, spec: str | None) -> dict:
    if not spec:
        shas = [head_sha(root)] if head_sha(root) else []
    elif ".." in spec:
        shas = git("rev-list", "--no-merges", spec, cwd=root).split()
    else:
        shas = [git("rev-parse", "--verify", spec + "^{commit}", cwd=root).strip()]
    total = {"human_additions": 0, "unknown_additions": 0, "ai_additions": 0, "ai_accepted": 0,
             "git_diff_deleted_lines": 0, "git_diff_added_lines": 0, "tool_model_breakdown": {}}
    for sha in shas:
        s = commit_stats(root, sha)
        for k in total:
            if k != "tool_model_breakdown":
                total[k] += s[k]
        for tm, b in s["tool_model_breakdown"].items():
            t = total["tool_model_breakdown"].setdefault(tm, {"ai_additions": 0, "ai_accepted": 0})
            t["ai_additions"] += b["ai_additions"]
            t["ai_accepted"] += b["ai_accepted"]
    total["commits"] = len(shas)
    return total


def blame(root: str, path: str, rev: str = "HEAD"):
    """Yield (short sha, who, line number, text). `who` is the agent for AI lines."""
    out = git("blame", "--line-porcelain", rev, "--", path, cwd=root)
    cache: dict[str, tuple[dict, dict]] = {}
    sha = orig_line = fname = author = None
    final = 0
    for line in out.split("\n"):
        if line.startswith("\t"):
            if sha is None:
                continue
            if sha not in cache:
                text = read_note(root, sha)
                cache[sha] = parse_note(text) if text else ({}, {})
            files, meta = cache[sha]
            key = (files.get(fname or path) or {}).get(orig_line)
            who = author or "?"
            if key:
                kind, tool, model = resolve_key(key, meta)
                if kind == "ai":
                    who = f"[{tool}]"
            yield sha[:8], who, final, line[1:]
            sha = None
            continue
        m = _BLAME_HEAD.match(line)
        if m:
            sha, orig_line, final, fname, author = m.group(1), int(m.group(2)), int(m.group(3)), None, None
        elif line.startswith("filename "):
            fname = line[9:]
        elif line.startswith("author "):
            author = line[7:]
