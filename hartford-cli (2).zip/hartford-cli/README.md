# hartford-cli

Tracks which lines of a commit were written by an AI agent and stores that as a git note,
in the open [Git AI Standard v3.0.0](https://github.com/git-ai-project/git-ai/blob/main/specs/git_ai_standard_v3.0.0.md)
format under `refs/notes/ai`. It is an independent implementation of the same idea as the
Git AI CLI: any tool that reads that standard, including the AI attribution platform
prototype, reads these notes unchanged.

Pure Python standard library. Needs Python 3.9+ and git.

## Install

    pipx install .          # or: pip install .
    hartford install        # git hooks (global) + Copilot and Claude Code hooks

Then work and commit as usual.

    hartford stats                  # last commit
    hartford stats main~20..main    # a range
    hartford stats --json           # same fields as `git ai stats --json`
    hartford blame src/app.py       # blame with the agent shown on AI lines
    hartford status                 # AI lines waiting for the next commit
    hartford doctor                 # check the setup and test the agent hook
    hartford log                    # recent hook activity

`hartford install` sets a global `core.hooksPath`. Its hooks chain to any hook in the
repo's own `.git/hooks`. If a repo sets its own `core.hooksPath` (husky and similar),
run `hartford init` inside that repo instead. `hartford uninstall` removes everything.

## How it works

1. **Checkpoints.** Agent hooks call `hartford checkpoint <agent> --hook` before and after
   each tool use. The call before a tool marks everything changed so far as human; the call
   after marks what the tool changed as that agent's session. State is kept in
   `.git/hartford/working.json` and never committed.
2. **Commit.** The post-commit hook takes the lines the commit added, looks up their tags
   and writes the authorship log as a note. Every commit gets a log, even with no AI lines,
   so coverage can be measured.
3. **Rewrites.** The post-rewrite hook carries logs across `commit --amend` and `rebase`
   by aligning old and new file contents.
4. **Sharing.** The pre-push hook pushes `refs/notes/ai`; the post-merge hook fetches it.
   `hartford sync` does both on demand. Turn the automatic part off with
   `git config hartford.autoSyncNotes false`.

Hooks never fail a git command or an agent step: any error is swallowed and exits 0.

## Agents

| Agent | Installed by | Notes |
|---|---|---|
| GitHub Copilot (CLI, app, VS Code agent) | `~/.copilot/hooks/hartford.json` | VS Code hook support is in preview and can be disabled by policy |
| Claude Code | `~/.claude/settings.json` | Edit, Write, MultiEdit, NotebookEdit |
| Anything else | call it yourself | `hartford checkpoint <name> --before` then `hartford checkpoint <name> --session ID --model M` |

The model name is taken from the hook payload when present, else `HARTFORD_MODEL`, else
`unknown`.

## Troubleshooting: `hartford status` shows nothing after an agent edit

Run `hartford doctor`. It checks the git hooks and the Copilot hook file, then runs the
configured hook command in a scratch repo exactly as an agent would. That separates the
two possible failures:

- **Self-test fails**: the hook command itself is broken (Python path, quoting, permissions).
  Run `hartford install` again from the environment you want to use.
- **Self-test passes but no agent call is logged**: the agent never called the hook. In
  VS Code, check that the chat Session Target is Copilot and you are in Agent mode, that
  Chat: Open Chat Customizations > Hooks lists hartford.json without a warning badge, that
  the folder is trusted, that `chat.useHooks` is not false, and that no organisation
  ChatHooks policy blocks user hooks.

If hartford.json does not appear under Hooks at all, VS Code is not reading the user-level
file. Put the hook inside the repo instead, which VS Code reads in every setup:

    hartford init --agent-hooks     # writes .github/hooks/hartford.json, kept out of git

Then reload the VS Code window.

Every hook call, and every reason one was skipped, is written to `~/.hartford/hook.log`
(`hartford log` shows the tail). A line such as `SKIP not in a git repo` or
`tagged 0 lines` tells you the hook ran and why it attributed nothing.

## Server-side squash and rebase merges

A merge done in the SCM web UI creates a commit where no hook ran. Rebuild its log in CI:

    git fetch origin '+refs/notes/ai:refs/notes/ai'
    hartford remap <merge-commit> <pr-commit>...
    git push origin refs/notes/ai

## Limits

- **Tested with simulated hook payloads**, not live agent sessions. The 10 end-to-end tests
  drive real git repos and real git hooks, and feed the CLI the payload shape the vendors
  document. Verify with a real Copilot and Claude Code session before rollout.
- **Inline completions are not captured.** Hooks fire on agent tool use only.
- **Not handled yet:** cherry-pick, stash and pop, and reset do not carry attribution.
  Amend, rebase, partial commits and squash (through `remap`) do.
- **Uses git hooks**, not a git wrapper, so a repo-level `core.hooksPath` needs `hartford init`.
- **Human lines are unattributed**, not "known human": there is no editor extension
  watching keystrokes.
- **Scale** is untested on very large repositories; each checkpoint runs `git status` and
  diffs the dirty files.
- Windows needs Git for Windows (git hooks are `sh` scripts). The Copilot hook carries a
  PowerShell form of the command; it has not been run on Windows yet, so run
  `hartford doctor` there first.

## Tests

    pip install pytest && pytest -q
