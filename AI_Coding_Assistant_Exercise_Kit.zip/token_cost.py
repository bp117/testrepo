"""Calculate hypothetical model cost from synthetic usage CSV rows."""
import argparse
import csv
from decimal import Decimal
from collections import defaultdict


def totals(path, input_rate=Decimal("2"), output_rate=Decimal("8")):
    result = defaultdict(lambda: {"input": 0, "output": 0, "cost": Decimal("0")})
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            incoming, outgoing = int(row["input_tokens"]), int(row["output_tokens"])
            entry = result[row["workflow"]]
            entry["input"] += incoming
            entry["output"] += outgoing
            entry["cost"] += (incoming * input_rate + outgoing * output_rate) / Decimal(1000000)
    return dict(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("csv")
    args = parser.parse_args()
    for name, value in sorted(totals(args.csv).items()):
        print(f"{name}: input={value['input']:,}, output={value['output']:,}, cost=${value['cost']:.3f}")
