import os

if os.environ.get("WORKSHOP_SOLUTION") == "1":
    from facilitator.solution import PaymentService
else:
    from payments.service import PaymentService
