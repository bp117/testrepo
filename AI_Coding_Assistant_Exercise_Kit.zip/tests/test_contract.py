import unittest
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from payments.gateway import FakeGateway, OutcomeUnknown
from payments.repository import Repository, Conflict
from tests.support import PaymentService


class ContractTests(unittest.TestCase):
    def test_changed_payload_conflicts(self):
        gateway = FakeGateway()
        service = PaymentService(Repository(), gateway)
        service.pay("K1", 10000, "DEMO-A")
        with self.assertRaises(Conflict):
            service.pay("K1", 15000, "DEMO-A")
        self.assertEqual(len(gateway.charges), 1)

    def test_concurrent_retries_create_one_charge(self):
        gateway = FakeGateway()
        rendezvous = Barrier(2)
        service = PaymentService(Repository(), gateway,
                                 before_charge=lambda: rendezvous.wait(timeout=3))
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(service.pay, "K1", 10000, "DEMO-A") for _ in range(2)]
            receipts = [f.result(timeout=5) for f in futures]
        self.assertEqual(len(gateway.charges), 1)
        self.assertEqual(receipts[0].charge_id, receipts[1].charge_id)

    def test_timeout_retry_reconciles_one_charge(self):
        gateway = FakeGateway(timeout_once=True)
        service = PaymentService(Repository(), gateway)
        with self.assertRaises(OutcomeUnknown):
            service.pay("K1", 10000, "DEMO-A")
        receipt = service.pay("K1", 10000, "DEMO-A")
        self.assertEqual(receipt.charge_id, gateway.charges[0].charge_id)
        self.assertEqual(len(gateway.charges), 1)


if __name__ == "__main__":
    unittest.main()
