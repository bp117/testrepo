import unittest
from payments.gateway import FakeGateway
from payments.repository import Repository
from tests.support import PaymentService


class BaselineTests(unittest.TestCase):
    def setUp(self):
        self.gateway = FakeGateway()
        self.service = PaymentService(Repository(), self.gateway)

    def test_one_charge(self):
        self.assertEqual(self.service.pay("K1", 10000, "DEMO-A").amount_cents, 10000)
        self.assertEqual(len(self.gateway.charges), 1)

    def test_sequential_same_payload_reuses_receipt(self):
        first = self.service.pay("K1", 10000, "DEMO-A")
        second = self.service.pay("K1", 10000, "DEMO-A")
        self.assertEqual(first.charge_id, second.charge_id)
        self.assertEqual(len(self.gateway.charges), 1)

    def test_invalid_amount(self):
        with self.assertRaises(ValueError):
            self.service.pay("K1", -1, "DEMO-A")


if __name__ == "__main__":
    unittest.main()
