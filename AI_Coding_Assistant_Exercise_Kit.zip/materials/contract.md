# Workshop contract

These are exercise assumptions, not a bank or provider specification.

- Same key, amount and account reuse one receipt.
- Same key with a changed amount or account raises Conflict.
- Two concurrent requests with the same payload create one provider charge.
- A provider timeout can occur after a charge. Reconcile before another charge.
- The first timed-out call raises OutcomeUnknown. A later retry recovers the receipt.
- Existing pay(key, amount_cents, account) callers keep working.
- Add no dependency. Keep before_charge usable for the deterministic race test.
- Use only the supplied fake gateway. All amounts are integer cents.

The fake gateway exposes charge(..., idempotency_key=...) and lookup(key).
The repository exposes reserve(key, payload_hash), save_completed(...), and
mark_unknown(...). reserve is atomic only inside this single Python process.

Out of scope: HTTP status codes, currencies, ledger postings, real credentials,
distributed transaction correctness, crashes, reconciliation workers and retention.
