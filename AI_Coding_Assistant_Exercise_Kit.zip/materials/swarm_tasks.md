# Three read-only worker briefs

Do not inspect facilitator/. Do not edit or execute code. Use payments/,
tests/ and materials/contract.md as evidence.

## Worker 1: execution mapper
Trace pay() from input to provider effect and local record. Return actual method
references, the unstable key behavior and where concurrency crosses the boundary.

## Worker 2: test analyst
Map each contract rule to an existing test. Name one missing assertion or case,
without changing the tests. Distinguish one-process from distributed coverage.

## Worker 3: side-effect reviewer
Explain the gateway timeout after a charge, the retry danger and the actual
lookup/idempotency API. State the limits of the fake provider and memory store.

## Required result schema for every worker
- Finding
- File or method location
- Evidence
- Unknown or assumption
- Recommended next check

Each report: at most 200 words. The owner resolves disagreements, implements
once, then tests the combined result.
