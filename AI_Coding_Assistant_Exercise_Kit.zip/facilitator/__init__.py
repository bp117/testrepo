"""Facilitator-only reference implementation."""
