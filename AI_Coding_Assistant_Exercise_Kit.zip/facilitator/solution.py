from payments.gateway import OutcomeUnknown
from payments.service import fingerprint


class PaymentService:
    """Reference for the workshop contract, not production payment code."""

    def __init__(self, repository, gateway, before_charge=None):
        self.repository = repository
        self.gateway = gateway
        self.before_charge = before_charge

    def pay(self, key, amount_cents, account):
        if not key or not isinstance(amount_cents, int) or amount_cents <= 0:
            raise ValueError("A key and a positive integer amount are required.")
        payload_hash = fingerprint(amount_cents, account)
        record = self.repository.reserve(key, payload_hash)
        if record.status == "COMPLETED":
            return record.receipt
        if record.status == "UNKNOWN":
            receipt = self.gateway.lookup(key)
            if receipt is None:
                raise OutcomeUnknown("Reconciliation required before another charge.")
            self.repository.save_completed(key, payload_hash, receipt)
            return receipt
        if self.before_charge:
            self.before_charge()
        try:
            receipt = self.gateway.charge(amount_cents, account, idempotency_key=key)
        except OutcomeUnknown:
            self.repository.mark_unknown(key, payload_hash)
            raise
        self.repository.save_completed(key, payload_hash, receipt)
        return receipt
