# AI Coding Assistant: Ready-to-use Exercise Kit

Open `Workshop_Exercises.html` in your browser. The workbook has 28 activities
mapped to all 32 slides, prompts, expected outputs and expandable answer keys.

## Setup (5 minutes)

1. Extract this ZIP to a local folder.
2. Install or use Python 3.10 or later. No Python packages need installing.
3. Open THIS extracted folder in your approved coding-assistant IDE.
4. Open a terminal in the extracted folder.
5. Run `python run_checks.py baseline`. Expected: 3 tests pass.
6. Run `python run_checks.py contract`. Expected on the starter: 3 intentional failures.

On systems where the Python command is `python3`, substitute that command.
Nothing connects to a bank, payment network or external server. There are no
real credentials or account numbers. `DEMO-A` is a fake account label.

## Use in the workshop

- Choose each activity's slide mapping in the workbook.
- Ask the assistant to use `payments/`, `tests/` and `materials/contract.md`.
- Keep `facilitator/` out of participant context until the debrief.
- A hosted/cloud agent needs this starter in an approved repository. A local
  chat or written task brief works without a cloud-agent account.
- Swarm exercises can use independent chat sessions or human role groups if
  your assistant does not offer subagents or parallel sessions.
- Do not execute the synthetic untrusted message. Display it for discussion.

## Reset between exercises

Extract a fresh copy to a new folder for each independent coding activity.
For comparison experiments, extract two copies (`experiment-a` and `experiment-b`).
Retain your observations separately. Do not overwrite participant work.
For Git exercises, initialize and commit a clean baseline in a local copy.

## Commands

`python run_checks.py baseline` — 3 starter sanity checks.

`python run_checks.py contract` — 3 regressions; initially fail.

`python run_checks.py all` — 6 tests; should pass after a complete fix.

`python run_checks.py all --solution` — 6 tests against the facilitator reference.

`python token_cost.py materials/token_usage.csv` — broad/focused cost illustration.

`python token_cost.py materials/swarm_usage.csv` — single/swarm cost illustration.

## Facilitator

`facilitator/solution.py` is a working reference for the workshop assumptions.
The answer keys in the HTML explain why it works and where its guarantees stop.
The reference uses atomic in-process reservation AND the fake provider's stable
idempotency key. It does not establish production correctness across replicas,
process crashes, key retention, authentication or real reconciliation systems.
The thread test exercises one process and is not a distributed systems test.

All usage data and pricing scenarios in this kit are synthetic teaching inputs.
Do not interpret them as measured Copilot usage, a real bill, or a benchmark.
