"""Cross-platform launcher for learner or facilitator tests."""
import argparse
import os
import unittest

parser = argparse.ArgumentParser()
parser.add_argument("suite", choices=["baseline", "contract", "all"], default="baseline", nargs="?")
parser.add_argument("--solution", action="store_true")
args = parser.parse_args()
os.environ["WORKSHOP_SOLUTION"] = "1" if args.solution else "0"
loader = unittest.TestLoader()
names = [f"tests.test_{args.suite}"] if args.suite != "all" else ["tests.test_baseline", "tests.test_contract"]
suite = loader.loadTestsFromNames(names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
