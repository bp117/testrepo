"""Deliberately small, local-only teaching application."""
