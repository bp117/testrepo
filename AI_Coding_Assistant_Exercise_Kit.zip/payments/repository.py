from dataclasses import dataclass
from threading import Lock


class Conflict(ValueError):
    """One logical request key cannot represent two different payloads."""


@dataclass(frozen=True)
class Record:
    payload_hash: str
    status: str
    receipt: object = None


class Repository:
    """Memory-only teaching store. reserve() is atomic within one process.

    Production replicas need shared durable storage and a real provider
    contract. A Python lock does not coordinate different processes.
    """

    def __init__(self):
        self._lock = Lock()
        self._records = {}

    def get(self, key):
        with self._lock:
            return self._records.get(key)

    def save_completed(self, key, payload_hash, receipt):
        with self._lock:
            self._records[key] = Record(payload_hash, "COMPLETED", receipt)

    def reserve(self, key, payload_hash):
        with self._lock:
            existing = self._records.get(key)
            if existing:
                if existing.payload_hash != payload_hash:
                    raise Conflict("The request key already has another payload.")
                return existing
            record = Record(payload_hash, "PENDING")
            self._records[key] = record
            return record

    def mark_unknown(self, key, payload_hash):
        with self._lock:
            existing = self._records.get(key)
            if not existing or existing.status != "COMPLETED":
                self._records[key] = Record(payload_hash, "UNKNOWN")
