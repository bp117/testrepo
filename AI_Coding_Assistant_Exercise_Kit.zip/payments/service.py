"""Intentionally flawed starter. Find and fix its contract violations."""
import hashlib
import json
from uuid import uuid4


def fingerprint(amount_cents, account):
    payload = json.dumps({"amount_cents": amount_cents, "account": account},
                         sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


class PaymentService:
    def __init__(self, repository, gateway, before_charge=None):
        self.repository = repository
        self.gateway = gateway
        # Test-only scheduling seam. Keep it usable in concurrency exercises.
        self.before_charge = before_charge

    def pay(self, key, amount_cents, account):
        if not key or not isinstance(amount_cents, int) or amount_cents <= 0:
            raise ValueError("A key and a positive integer amount are required.")
        payload_hash = fingerprint(amount_cents, account)
        existing = self.repository.get(key)
        if existing:
            return existing.receipt
        if self.before_charge:
            self.before_charge()
        receipt = self.gateway.charge(amount_cents, account,
                                      idempotency_key=str(uuid4()))
        self.repository.save_completed(key, payload_hash, receipt)
        return receipt
