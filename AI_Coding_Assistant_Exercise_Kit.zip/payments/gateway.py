from dataclasses import dataclass
from threading import Lock


class OutcomeUnknown(RuntimeError):
    """The simulated provider recorded a charge but its response timed out."""


@dataclass(frozen=True)
class Receipt:
    charge_id: str
    amount_cents: int
    account: str


class FakeGateway:
    """No network, real accounts, credentials, or monetary transactions.

    The provider deduplicates on idempotency_key across all clients sharing
    this instance. The local service must enforce its own payload contract.
    """

    def __init__(self, timeout_once=False):
        self._lock = Lock()
        self._records = {}
        self.timeout_once = timeout_once
        self.charges = []

    def charge(self, amount_cents, account, *, idempotency_key):
        with self._lock:
            if idempotency_key in self._records:
                return self._records[idempotency_key]
            receipt = Receipt(f"ch_{len(self.charges) + 1}", amount_cents, account)
            self._records[idempotency_key] = receipt
            self.charges.append(receipt)
            timed_out = self.timeout_once
            self.timeout_once = False
        if timed_out:
            raise OutcomeUnknown("The response timed out after the charge.")
        return receipt

    def lookup(self, idempotency_key):
        with self._lock:
            return self._records.get(idempotency_key)
