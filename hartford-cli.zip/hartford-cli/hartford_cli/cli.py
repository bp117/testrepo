"""hartford: track AI-written code in git.

  hartford install            set up git hooks and agent hooks for this user
  hartford init               set up git hooks in the current repo only
  hartford checkpoint ...     record who changed the working tree (called by agent hooks)
  hartford status             show attribution waiting for the next commit
  hartford stats [rev|a..b]   AI vs human line counts (add --json)
  hartford blame <file>       git blame with the agent shown for AI lines
  hartford show [rev]         print a commit's authorship log
  hartford sync [remote]      fetch, merge and push refs/notes/ai
  hartford remap <new> <old>… rebuild a log after a server-side squash or rebase
  hartford uninstall          remove everything `install` added
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import stat
import sys
from pathlib import Path

from . import __version__, core

HOOKS = ("post-commit", "post-rewrite", "pre-push", "post-merge")
MARK = "# hartford-cli"
EDIT_MATCHER = "Edit|Write|MultiEdit|NotebookEdit"


def _self_cmd() -> str:
    """Absolute command that works from GUI git clients with a bare PATH."""
    return f"{shlex.quote(sys.executable)} -m hartford_cli"


def _home() -> Path:
    return Path(os.environ.get("HARTFORD_HOME") or Path.home())


# ------------------------------------------------------------ git hooks

def _hook_script(name: str, chain_local: bool) -> str:
    cmd = _self_cmd()
    lines = ["#!/bin/sh", f"{MARK} managed hook: {name}. Never blocks git."]
    if name == "post-rewrite":
        lines += ['input=$(cat)',
                  f'printf \'%s\\n\' "$input" | {cmd} hook {name} "$@" >/dev/null 2>&1 || true']
        relay = 'printf \'%s\\n\' "$input" | '
    else:
        lines += [f'{cmd} hook {name} "$@" </dev/null >/dev/null 2>&1 || true']
        relay = ""
    if chain_local:
        lines += ['local_hook="$(git rev-parse --git-dir 2>/dev/null)/hooks/' + name + '"',
                  'if [ -x "$local_hook" ]; then',
                  f'  {relay}"$local_hook" "$@" || exit $?',
                  'fi']
    return "\n".join(lines) + "\n"


def _write_exec(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def install_global_git_hooks() -> str:
    current = core.git("config", "--global", "--get", "core.hooksPath", check=False).strip()
    target = _home() / ".hartford" / "hooks"
    if current and Path(current).expanduser() != target:
        return (f"skipped git hooks: core.hooksPath is already set to {current}. "
                "Run `hartford init` inside each repo instead.")
    for name in HOOKS:
        _write_exec(target / name, _hook_script(name, chain_local=True))
    core.git("config", "--global", "core.hooksPath", str(target))
    return f"git hooks installed in {target} (global core.hooksPath)"


def init_repo_hooks(root: str) -> str:
    local = core.git("config", "--local", "--get", "core.hooksPath", cwd=root, check=False).strip()
    hooks_dir = (Path(root) / local) if local else core.git_dir(root) / "hooks"
    cmd = _self_cmd()
    for name in HOOKS:
        path = hooks_dir / name
        existing = path.read_text() if path.exists() else ""
        if MARK in existing:
            continue
        if name == "post-rewrite":
            if existing:
                # an existing hook reads stdin; do not fight it for the input
                return (f"{path} already exists and reads stdin. Add this line to it by hand:\n"
                        f"  {cmd} hook post-rewrite \"$@\"")
            call = f'{cmd} hook {name} "$@" >/dev/null 2>&1 || true'
        else:
            call = f'{cmd} hook {name} "$@" </dev/null >/dev/null 2>&1 || true'
        body = existing if existing else "#!/bin/sh\n"
        _write_exec(path, body.rstrip("\n") + f"\n{MARK}\n{call}\n")
    return f"git hooks installed in {hooks_dir}"


def uninstall_git_hooks() -> str:
    target = _home() / ".hartford" / "hooks"
    current = core.git("config", "--global", "--get", "core.hooksPath", check=False).strip()
    if current and Path(current).expanduser() == target:
        core.git("config", "--global", "--unset", "core.hooksPath", check=False)
    for name in HOOKS:
        (target / name).unlink(missing_ok=True)
    return "global git hooks removed"


# ----------------------------------------------------------- agent hooks

def _load_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def install_copilot() -> str:
    """User-level Copilot hooks, shared by the Copilot CLI, app and VS Code agent."""
    path = _home() / ".copilot" / "hooks" / "hartford.json"
    cmd = f"{_self_cmd()} checkpoint copilot --hook"
    _save_json(path, {"version": 1, "hooks": {
        "PreToolUse": [{"type": "command", "command": cmd, "timeoutSec": 30}],
        "PostToolUse": [{"type": "command", "command": cmd, "timeoutSec": 30}]}})
    return f"Copilot hooks written to {path}"


def install_claude() -> str:
    path = _home() / ".claude" / "settings.json"
    data = _load_json(path)
    cmd = f"{_self_cmd()} checkpoint claude --hook"
    hooks = data.setdefault("hooks", {})
    for event in ("PreToolUse", "PostToolUse"):
        entries = [e for e in hooks.get(event, []) if MARK not in json.dumps(e)]
        entries.append({"matcher": EDIT_MATCHER,
                        "hooks": [{"type": "command", "command": f"{cmd} {MARK}"}]})
        hooks[event] = entries
    _save_json(path, data)
    return f"Claude Code hooks merged into {path}"


def uninstall_agents() -> str:
    (_home() / ".copilot" / "hooks" / "hartford.json").unlink(missing_ok=True)
    path = _home() / ".claude" / "settings.json"
    data = _load_json(path)
    if "hooks" in data:
        for event in list(data["hooks"]):
            data["hooks"][event] = [e for e in data["hooks"][event] if MARK not in json.dumps(e)]
            if not data["hooks"][event]:
                del data["hooks"][event]
        _save_json(path, data)
    return "agent hooks removed"


# ------------------------------------------------------------- commands

def _root_or_exit(cwd: str | None = None) -> str:
    root = core.repo_root(cwd)
    if not root:
        raise SystemExit("not inside a git repository")
    return root


def cmd_checkpoint(args) -> int:
    payload: dict = {}
    if args.hook:
        try:
            raw = sys.stdin.read()
            payload = json.loads(raw) if raw.strip() else {}
        except (json.JSONDecodeError, OSError):
            payload = {}
    # Hooks must never break the agent: any failure exits 0 silently.
    try:
        root = core.repo_root(payload.get("cwd") or None)
        if not root:
            return 0
        event = str(payload.get("hook_event_name") or payload.get("hookEventName") or "")
        before = args.before or event.lower() == "pretooluse"
        if args.agent == "human" or before:
            core.checkpoint(root, None)
            return 0
        conv = (args.session or payload.get("session_id") or payload.get("chat_session_id")
                or payload.get("sessionId") or os.environ.get("HARTFORD_SESSION") or "unknown")
        model = (args.model or payload.get("model") or os.environ.get("HARTFORD_MODEL")
                 or "unknown")
        sid = core.session_id(args.agent, str(conv))
        email = core.git("config", "user.email", cwd=root, check=False).strip()
        record = {"agent_id": {"tool": args.agent, "id": str(conv), "model": str(model)}}
        if email:
            record["human_author"] = email
        touched = core.checkpoint(root, f"{sid}::{core.trace_id()}", (sid, record))
        if not args.hook:
            for path, n in touched.items():
                print(f"{path}: {n} lines attributed to {args.agent}")
    except Exception:  # noqa: BLE001
        if not args.hook:
            raise
    return 0


def cmd_hook(args) -> int:
    try:
        root = core.repo_root()
        if not root:
            return 0
        if args.name == "post-commit":
            core.post_commit(root)
        elif args.name == "post-rewrite":
            pairs = [tuple(ln.split()[:2]) for ln in sys.stdin.read().splitlines()
                     if len(ln.split()) >= 2]
            core.post_rewrite(root, pairs)
        elif args.name in ("pre-push", "post-merge"):
            if os.environ.get("HARTFORD_PUSHING"):
                return 0
            auto = core.git("config", "--get", "hartford.autoSyncNotes", cwd=root, check=False).strip()
            if auto.lower() == "false":
                return 0
            remote = args.rest[0] if (args.name == "pre-push" and args.rest) else "origin"
            core.sync_notes(root, remote, push=args.name == "pre-push", timeout=20)
    except Exception:  # noqa: BLE001  hooks never fail a git command
        pass
    return 0


def cmd_status(args) -> int:
    root = _root_or_exit()
    state = core.load_state(root)
    rows = []
    for path, entry in sorted(state["files"].items()):
        by_tool: dict[str, int] = {}
        for key in entry["keys"]:
            if key:
                tool = (state["sessions"].get(key.split("::", 1)[0], {}).get("agent_id") or {}).get("tool", "?")
                by_tool[tool] = by_tool.get(tool, 0) + 1
        if by_tool:
            rows.append((path, by_tool))
    if not rows:
        print("No AI attribution waiting for the next commit.")
        return 0
    print("AI-attributed lines in the working tree:")
    for path, by_tool in rows:
        print(f"  {path}: " + ", ".join(f"{n} by {t}" for t, n in sorted(by_tool.items())))
    return 0


def cmd_stats(args) -> int:
    root = _root_or_exit()
    s = core.range_stats(root, args.rev)
    if args.json:
        out = {k: v for k, v in s.items() if k != "commits"}
        print(json.dumps(out, indent=2))
        return 0
    total = s["git_diff_added_lines"]
    pct = (lambda n: f"{100 * n / total:.0f}%") if total else (lambda n: "-")
    print(f"{s['commits']} commit(s), {total} lines added, {s['git_diff_deleted_lines']} deleted")
    print(f"  AI            {s['ai_additions']:>7}  {pct(s['ai_additions'])}")
    print(f"  known human   {s['human_additions']:>7}  {pct(s['human_additions'])}")
    print(f"  unattributed  {s['unknown_additions']:>7}  {pct(s['unknown_additions'])}")
    for tm, b in sorted(s["tool_model_breakdown"].items(), key=lambda kv: -kv[1]["ai_additions"]):
        print(f"    {tm}: {b['ai_additions']}")
    return 0


def cmd_blame(args) -> int:
    root = _root_or_exit()
    rel = os.path.relpath(os.path.abspath(args.file), root)
    for sha, who, n, text in core.blame(root, rel, args.rev):
        print(f"{sha} {who[:18]:<18} {n:>5}) {text}")
    return 0


def cmd_show(args) -> int:
    root = _root_or_exit()
    sha = core.git("rev-parse", "--verify", args.rev + "^{commit}", cwd=root).strip()
    text = core.read_note(root, sha)
    if text is None:
        print(f"no authorship log on {sha[:10]}")
        return 1
    sys.stdout.write(text)
    return 0


def cmd_install(args) -> int:
    agents = [a for a in args.agents.split(",") if a]
    if not args.no_git_hooks:
        print(install_global_git_hooks())
    if "copilot" in agents:
        print(install_copilot())
    if "claude" in agents:
        print(install_claude())
    print("Done. Commit as usual; run `hartford stats` to see attribution.")
    return 0


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="hartford", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", action="version", version=f"hartford-cli {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("install")
    p.add_argument("--agents", default="copilot,claude", help="comma list: copilot,claude")
    p.add_argument("--no-git-hooks", action="store_true")
    p.set_defaults(fn=cmd_install)

    p = sub.add_parser("init")
    p.set_defaults(fn=lambda a: print(init_repo_hooks(_root_or_exit())) or 0)

    p = sub.add_parser("uninstall")
    p.set_defaults(fn=lambda a: print(uninstall_git_hooks(), uninstall_agents(), sep="\n") or 0)

    p = sub.add_parser("checkpoint")
    p.add_argument("agent", help="agent name (copilot, claude, cursor, ...) or `human`")
    p.add_argument("--hook", action="store_true", help="read the agent's hook payload from stdin")
    p.add_argument("--before", action="store_true", help="pre-edit checkpoint: changes so far are human")
    p.add_argument("--session")
    p.add_argument("--model")
    p.set_defaults(fn=cmd_checkpoint)

    p = sub.add_parser("hook")
    p.add_argument("name", choices=HOOKS)
    p.add_argument("rest", nargs="*")
    p.set_defaults(fn=cmd_hook)

    sub.add_parser("status").set_defaults(fn=cmd_status)

    p = sub.add_parser("stats")
    p.add_argument("rev", nargs="?")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_stats)

    p = sub.add_parser("blame")
    p.add_argument("file")
    p.add_argument("rev", nargs="?", default="HEAD")
    p.set_defaults(fn=cmd_blame)

    p = sub.add_parser("show")
    p.add_argument("rev", nargs="?", default="HEAD")
    p.set_defaults(fn=cmd_show)

    p = sub.add_parser("sync")
    p.add_argument("remote", nargs="?", default="origin")
    p.set_defaults(fn=lambda a: print(core.sync_notes(_root_or_exit(), a.remote)) or 0)

    p = sub.add_parser("remap")
    p.add_argument("new")
    p.add_argument("old", nargs="+")
    p.set_defaults(fn=lambda a: 0 if core.remap(
        _root_or_exit(),
        core.git("rev-parse", a.new, cwd=_root_or_exit()).strip(),
        [core.git("rev-parse", o, cwd=_root_or_exit()).strip() for o in a.old]) else 1)

    args = ap.parse_args(argv)
    try:
        raise SystemExit(args.fn(args) or 0)
    except core.GitError as exc:
        raise SystemExit(f"hartford: {exc}")


if __name__ == "__main__":
    main()
