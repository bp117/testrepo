"""End-to-end tests: real git repos, real hooks, simulated agent hook payloads."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from hartford_cli import core  # noqa: E402


@pytest.fixture()
def env(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    e = dict(os.environ,
             HOME=str(home), HARTFORD_HOME=str(home),
             GIT_CONFIG_GLOBAL=str(home / "gitconfig"), GIT_CONFIG_NOSYSTEM="1",
             GIT_AUTHOR_NAME="Dev", GIT_AUTHOR_EMAIL="dev@example.com",
             GIT_COMMITTER_NAME="Dev", GIT_COMMITTER_EMAIL="dev@example.com",
             PYTHONPATH=str(ROOT))
    e.pop("HARTFORD_PUSHING", None)
    for k, v in e.items():
        monkeypatch.setenv(k, v)
    subprocess.run(["git", "config", "--global", "user.email", "dev@example.com"], env=e, check=True)
    subprocess.run(["git", "config", "--global", "user.name", "Dev"], env=e, check=True)
    subprocess.run(["git", "config", "--global", "init.defaultBranch", "main"], env=e, check=True)
    return e


def run(cwd, *args, env, stdin=None, check=True):
    p = subprocess.run(list(args), cwd=cwd, env=env, input=stdin, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise AssertionError(f"{args} failed: {p.stderr}\n{p.stdout}")
    return p.stdout


def hartford(cwd, *args, env, stdin=None, check=True):
    return run(cwd, sys.executable, "-m", "hartford_cli", *args, env=env, stdin=stdin, check=check)


def agent(cwd, env, name, event, session="sess-1", model=None):
    payload = {"hook_event_name": event, "session_id": session, "cwd": str(cwd),
               "tool_name": "edit", "tool_input": {}}
    if model:
        payload["model"] = model
    hartford(cwd, "checkpoint", name, "--hook", env=env, stdin=json.dumps(payload))


def lines(prefix, n):
    return "".join(f"{prefix} {i}\n" for i in range(1, n + 1))


def new_repo(path: Path, env) -> Path:
    path.mkdir(parents=True)
    run(path, "git", "init", "-q", env=env)
    hartford(path, "init", env=env)
    (path / "app.py").write_text(lines("base", 5))
    run(path, "git", "add", "-A", env=env)
    run(path, "git", "commit", "-qm", "base", env=env)
    return path


def stats(cwd, env, rev=None):
    args = ["stats", "--json"] + ([rev] if rev else [])
    return json.loads(hartford(cwd, *args, env=env))


def test_basic_flow_and_stats_schema(tmp_path, env):
    r = new_repo(tmp_path / "r", env)
    assert core.read_note(str(r), "HEAD") is not None       # even a no-AI commit gets a log
    assert stats(r, env)["ai_additions"] == 0

    # human types two lines, then the agent runs
    (r / "app.py").write_text(lines("base", 5) + "human a\nhuman b\n")
    agent(r, env, "copilot", "PreToolUse")
    (r / "app.py").write_text(lines("base", 5) + "human a\nhuman b\n" + lines("ai", 3))
    (r / "gen.py").write_text(lines("gen", 6))
    agent(r, env, "copilot", "PostToolUse", model="gpt-5")
    assert "gen.py: 6 by copilot" in hartford(r, "status", env=env)

    # the human rewrites one generated line before committing, with no checkpoint
    (r / "gen.py").write_text(lines("gen", 6).replace("gen 4\n", "hand-fixed\n"))
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "feature", env=env)

    s = stats(r, env)
    assert s["git_diff_added_lines"] == 11
    assert s["ai_additions"] == 8 and s["ai_accepted"] == 8      # 3 in app.py + 5 in gen.py
    assert s["human_additions"] == 0 and s["unknown_additions"] == 3
    assert s["human_additions"] + s["unknown_additions"] + s["ai_additions"] == s["git_diff_added_lines"]
    assert s["tool_model_breakdown"] == {"copilot::gpt-5": {"ai_additions": 8, "ai_accepted": 8}}
    assert set(s) == {"human_additions", "unknown_additions", "ai_additions", "ai_accepted",
                      "git_diff_deleted_lines", "git_diff_added_lines", "tool_model_breakdown"}

    note = hartford(r, "show", env=env)
    att, meta = note.split("\n---\n", 1)
    meta = json.loads(meta)
    assert meta["schema_version"] == "authorship/3.0.0"
    assert meta["base_commit_sha"] == run(r, "git", "rev-parse", "HEAD", env=env).strip()
    (sid, rec), = meta["sessions"].items()
    assert sid == core.session_id("copilot", "sess-1")
    assert rec["agent_id"] == {"tool": "copilot", "id": "sess-1", "model": "gpt-5"}
    assert rec["human_author"] == "dev@example.com"
    assert att.splitlines()[0] == "app.py"
    assert att.splitlines()[1].startswith(f"  {sid}::t_") and att.splitlines()[1].endswith(" 8-10")
    assert att.splitlines()[3].endswith(" 1-3,5-6")
    assert "No AI attribution" in hartford(r, "status", env=env)

    blame = hartford(r, "blame", "gen.py", env=env).splitlines()
    assert "[copilot]" in blame[0] and "[copilot]" not in blame[3] and "Dev" in blame[3]


def test_two_agents_and_human_override(tmp_path, env):
    r = new_repo(tmp_path / "r", env)
    (r / "a.py").write_text(lines("cop", 4))
    agent(r, env, "copilot", "PostToolUse", session="c1", model="gpt-5")
    agent(r, env, "claude", "PreToolUse", session="k1")
    (r / "a.py").write_text(lines("cop", 4) + lines("cl", 2))
    agent(r, env, "claude", "PostToolUse", session="k1", model="sonnet")
    # human edit seen by the next pre-tool checkpoint wipes the AI tag on that line
    (r / "a.py").write_text((lines("cop", 4) + lines("cl", 2)).replace("cop 2\n", "mine\n"))
    agent(r, env, "claude", "PreToolUse", session="k1")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "two agents", env=env)
    s = stats(r, env)
    assert s["tool_model_breakdown"] == {
        "copilot::gpt-5": {"ai_additions": 3, "ai_accepted": 3},
        "claude::sonnet": {"ai_additions": 2, "ai_accepted": 2}}
    assert s["unknown_additions"] == 1


def test_partial_commit_keeps_the_rest(tmp_path, env):
    r = new_repo(tmp_path / "r", env)
    (r / "one.py").write_text(lines("one", 3))
    (r / "two.py").write_text(lines("two", 4))
    agent(r, env, "copilot", "PostToolUse")
    run(r, "git", "add", "one.py", env=env)
    run(r, "git", "commit", "-qm", "one", env=env)
    assert stats(r, env)["ai_additions"] == 3
    assert "two.py: 4 by copilot" in hartford(r, "status", env=env)
    run(r, "git", "add", "two.py", env=env)
    run(r, "git", "commit", "-qm", "two", env=env)
    assert stats(r, env)["ai_additions"] == 4
    assert stats(r, env, "HEAD~2..HEAD")["ai_additions"] == 7


def test_amend_keeps_attribution(tmp_path, env):
    r = new_repo(tmp_path / "r", env)
    (r / "gen.py").write_text(lines("gen", 5))
    agent(r, env, "copilot", "PostToolUse")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "gen", env=env)
    (r / "gen.py").write_text("header by hand\n" + lines("gen", 5))
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-q", "--amend", "--no-edit", env=env)
    s = stats(r, env)
    assert s["git_diff_added_lines"] == 6 and s["ai_additions"] == 5
    assert hartford(r, "show", env=env).splitlines()[1].endswith(" 2-6")


def test_rebase_carries_logs(tmp_path, env):
    r = new_repo(tmp_path / "r", env)
    run(r, "git", "checkout", "-qb", "feature", env=env)
    (r / "gen.py").write_text(lines("gen", 5))
    agent(r, env, "copilot", "PostToolUse")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "gen", env=env)
    old = run(r, "git", "rev-parse", "HEAD", env=env).strip()
    run(r, "git", "checkout", "-q", "main", env=env)
    (r / "other.txt").write_text("x\n")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "main moves", env=env)
    run(r, "git", "checkout", "-q", "feature", env=env)
    run(r, "git", "rebase", "-q", "main", env=env)
    new = run(r, "git", "rev-parse", "HEAD", env=env).strip()
    assert new != old
    assert stats(r, env)["ai_additions"] == 5


def test_remap_after_squash_merge(tmp_path, env):
    r = new_repo(tmp_path / "r", env)
    run(r, "git", "checkout", "-qb", "feature", env=env)
    (r / "a.py").write_text(lines("a", 4))
    agent(r, env, "copilot", "PostToolUse", session="s-a", model="gpt-5")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "a", env=env)
    (r / "b.py").write_text(lines("b", 3))
    agent(r, env, "claude", "PostToolUse", session="s-b", model="sonnet")
    (r / "a.py").write_text(lines("a", 4) + "typed by hand\n")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "b", env=env)
    olds = run(r, "git", "rev-list", "main..feature", env=env).split()

    # simulate a server-side squash: a commit made where hartford was not running
    run(r, "git", "checkout", "-q", "main", env=env)
    run(r, "git", "merge", "-q", "--squash", "feature", env=env)
    run(r, "git", "-c", "core.hooksPath=/dev/null", "commit", "-qm", "squash", env=env)
    assert core.read_note(str(r), "HEAD") is None
    hartford(r, "remap", "HEAD", *olds, env=env)
    s = stats(r, env)
    assert s["git_diff_added_lines"] == 8 and s["ai_additions"] == 7 and s["unknown_additions"] == 1
    assert s["tool_model_breakdown"]["copilot::gpt-5"]["ai_additions"] == 4
    assert s["tool_model_breakdown"]["claude::sonnet"]["ai_additions"] == 3


def test_notes_travel_with_push_and_sync(tmp_path, env):
    remote = tmp_path / "remote.git"
    run(tmp_path, "git", "init", "-q", "--bare", str(remote), env=env)
    a = new_repo(tmp_path / "a", env)
    run(a, "git", "remote", "add", "origin", str(remote), env=env)
    (a / "gen.py").write_text(lines("gen", 5))
    agent(a, env, "copilot", "PostToolUse")
    run(a, "git", "add", "-A", env=env)
    run(a, "git", "commit", "-qm", "gen", env=env)
    run(a, "git", "push", "-q", "origin", "main", env=env)      # pre-push hook pushes the notes
    assert run(remote, "git", "rev-parse", "--verify", "refs/notes/ai", env=env).strip()

    run(tmp_path, "git", "clone", "-q", str(remote), "b", env=env)
    b = tmp_path / "b"
    assert stats(b, env)["ai_additions"] == 0                    # clone does not fetch notes
    assert hartford(b, "sync", env=env).strip() == "synced"
    assert stats(b, env)["ai_additions"] == 5


def test_hooks_never_fail(tmp_path, env):
    outside = tmp_path / "not-a-repo"
    outside.mkdir()
    p = subprocess.run([sys.executable, "-m", "hartford_cli", "checkpoint", "copilot", "--hook"],
                       cwd=outside, env=env, input="{not json", capture_output=True, text=True)
    assert p.returncode == 0 and p.stdout == ""
    p = subprocess.run([sys.executable, "-m", "hartford_cli", "hook", "post-commit"],
                       cwd=outside, env=env, capture_output=True, text=True)
    assert p.returncode == 0


def test_install_and_uninstall(tmp_path, env):
    home = Path(env["HOME"])
    (home / ".claude").mkdir()
    (home / ".claude" / "settings.json").write_text(json.dumps(
        {"model": "x", "hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": []}]}}))
    out = hartford(tmp_path, "install", env=env)
    assert "git hooks installed" in out
    hooks_path = run(tmp_path, "git", "config", "--global", "core.hooksPath", env=env).strip()
    assert (Path(hooks_path) / "post-commit").exists()
    cop = json.loads((home / ".copilot" / "hooks" / "hartford.json").read_text())
    assert set(cop["hooks"]) == {"PreToolUse", "PostToolUse"}
    claude = json.loads((home / ".claude" / "settings.json").read_text())
    assert claude["model"] == "x" and len(claude["hooks"]["PreToolUse"]) == 2

    # global hooks work in a fresh repo with no per-repo setup
    r = tmp_path / "g"
    r.mkdir()
    run(r, "git", "init", "-q", env=env)
    (r / "gen.py").write_text(lines("gen", 4))
    agent(r, env, "copilot", "PostToolUse")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "gen", env=env)
    assert stats(r, env)["ai_additions"] == 4

    hartford(tmp_path, "uninstall", env=env)
    assert run(tmp_path, "git", "config", "--global", "--get", "core.hooksPath", env=env,
               check=False).strip() == ""
    assert not (home / ".copilot" / "hooks" / "hartford.json").exists()
    claude = json.loads((home / ".claude" / "settings.json").read_text())
    assert claude["hooks"]["PreToolUse"] == [{"matcher": "Bash", "hooks": []}]


def test_platform_parser_reads_our_notes(tmp_path, env):
    platform = ROOT.parent / "ai-attribution-platform"
    if not (platform / "aiattr" / "notes.py").exists():
        pytest.skip("ai-attribution-platform not next to this project")
    sys.path.insert(0, str(platform))
    from aiattr.notes import parse_note

    r = new_repo(tmp_path / "r", env)
    (r / "gen.py").write_text(lines("gen", 6))
    agent(r, env, "copilot", "PostToolUse", model="gpt-5")
    run(r, "git", "add", "-A", env=env)
    run(r, "git", "commit", "-qm", "gen", env=env)
    log = parse_note(hartford(r, "show", env=env))
    assert [(x.file, x.start, x.end, x.author.kind, x.author.tool, x.author.model)
            for x in log.ranges] == [("gen.py", 1, 6, "ai", "copilot", "gpt-5")]
