# JSONL import formats

One JSON object per line. `repo` is the `name` from config.yaml. Timestamps are ISO 8601.

prs.jsonl
    {"repo":"payments-api","number":412,"author":"dev@example.com",
     "created_at":"2026-10-01T09:00:00Z","first_review_at":"2026-10-01T13:00:00Z",
     "merged_at":"2026-10-02T09:00:00Z","merge_commit_sha":"<40-hex>","commits":["<40-hex>"]}

deployments.jsonl
    {"repo":"payments-api","sha":"<40-hex>","environment":"production",
     "deployed_at":"2026-10-03T10:00:00Z","status":"success"}

incidents.jsonl   (kind: incident | rollback)
    {"repo":"payments-api","ref":"INC0012345","kind":"incident",
     "caused_by_sha":"<40-hex>","opened_at":"2026-10-04T02:00:00Z"}

generated.jsonl   (optional agent telemetry: lines offered or generated per day)
    {"repo":"payments-api","day":"2026-10-01","tool":"copilot","model":"gpt-5","generated_lines":1200}
