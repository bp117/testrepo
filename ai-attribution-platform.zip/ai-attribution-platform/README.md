# AI attribution platform (prototype)

Reads the AI authorship logs that the open-source [Git AI](https://github.com/git-ai-project/git-ai)
CLI attaches to commits, joins them with pull requests, deployments and incidents, and
derives software-factory metrics in Postgres, or in SQLite until Postgres is available. It is a self-built alternative to the
aggregation layer of a hosted attribution product, sized for a pilot.

It does not generate attribution. Developers still need the Git AI CLI (or another tool
that writes the same open format) on their machines. This service only reads git.

## What you get

| Group | Metrics |
|---|---|
| AI share and survival | Attribution coverage, AI share of added lines, share of AI lines still alive after 30 and 90 days, with a non-AI baseline |
| Prompt to production | AI lines generated (optional telemetry), committed, merged, deployed, still in the codebase |
| Agent and model comparison | Volume, share, survival, later-failed share and fully-AI commit share per agent and model |
| Flow and quality | Review wait, open-to-merge, merge-to-deploy and change failure for pull requests, split by AI share |

Team is the smallest unit reported. Author emails are stored only as salted hashes.

## Quick start

    pip install -r requirements.txt
    cp config.example.yaml config.yaml   # list your repos and teams

    python -m aiattr init-db
    python -m aiattr run                 # ingest commits and logs, take survival snapshots
    python -m aiattr import --prs prs.jsonl --deployments deployments.jsonl --incidents incidents.jsonl
    python -m aiattr serve               # dashboard on http://127.0.0.1:8000

Try it on generated demo repos first (uses SQLite, nothing else to install):

    python tests/build_demo.py /tmp/demo
    python -m aiattr --config /tmp/demo/config.yaml init-db
    python -m aiattr --config /tmp/demo/config.yaml run
    python -m aiattr --config /tmp/demo/config.yaml import --prs /tmp/demo/prs.jsonl \
        --deployments /tmp/demo/deployments.jsonl --generated /tmp/demo/generated.jsonl
    python -m aiattr --config /tmp/demo/config.yaml serve

Run the tests. They always run on SQLite; set `TEST_DATABASE_URL` to run the same checks
on Postgres too (every table in that database is dropped and recreated):

    pytest -q
    TEST_DATABASE_URL=postgresql://aiattr:aiattr@localhost:5432/aiattr pytest -q

## Choosing a database

`database_url` in config.yaml (or the `DATABASE_URL` env var) picks the backend.

| URL | Backend | Needs |
|---|---|---|
| `sqlite:///aiattr.db` | SQLite file, relative path | Nothing beyond Python |
| `sqlite:////var/lib/aiattr/aiattr.db` | SQLite file, absolute path | Nothing beyond Python |
| `postgresql://user:pass@host:5432/db` | Postgres 14+ | `psycopg`; `docker compose up -d` starts a local one |

Both backends run the same queries and return the same numbers; the test suite checks
every metric on each and checks that a copied database reports identical results.

When Postgres is provisioned, move the data across and switch:

    python -m aiattr copy-db --to postgresql://user:pass@host:5432/aiattr
    # then set database_url to the Postgres URL

`copy-db` creates the schema in the destination and refuses to run if it already holds data.

SQLite is a single file with one writer at a time. That suits one scheduled collector and
a handful of dashboard readers. Move to Postgres before running collectors in parallel,
putting the store on shared network storage, or giving many people the dashboard.

## How it works

1. **Collect.** `ingest` walks every commit on a branch, remote branch or PR head. For
   each one it reads the note under `refs/notes/ai`, parses it (Git AI Standard v3.0.0:
   session, legacy and known-human keys) and splits the commit's added lines into
   `ai`, `human`, `untracked` (log present, line not attested) and `no_note` (no log).
   The parts always sum to the diff's added lines. Re-running is safe, and a commit whose
   log arrives later, for example from a CI rewrite after a squash merge, is refreshed.
2. **Snapshot.** `survival` runs `git blame` over the default branch head and maps each
   surviving line back to the commit and attested range it came from.
3. **Join.** `import` loads pull requests, deployments, incidents and optional agent
   telemetry from JSONL (formats in `sample/README.md`). `link-deploys` stamps each commit
   with the first production deploy that contained it. Reverts are detected from git itself.
4. **Serve.** `aiattr/metrics.py` holds every metric in SQL both backends accept, with date bucketing and medians done in Python. The API and the
   dashboard only call those functions.

## Metric definitions

- **Coverage** = commits with an authorship log / all non-merge commits on the default branch.
- **AI share** = AI-attested added lines / added lines in commits that have a log.
- **Survival (N days)** = of lines added by default-branch commits at least N days old,
  the share still present at the latest snapshot. Reported for AI lines and for other lines.
- **Later failed** = the commit was reverted on the default branch, or an incident or
  rollback record names it as the cause.
- **Fully-AI commit** = one agent wrote at least 90% of the commit's added lines.
- **Change failure (PRs)** = merged PRs containing a failed commit / merged PRs.

## Getting the event files

Any system that can emit the JSONL shapes works. Starting points for GitHub (adapt and
test in your environment; these commands were not run as part of building this prototype):

    gh api --paginate "repos/ORG/REPO/pulls?state=closed&per_page=100"
    gh api --paginate "repos/ORG/REPO/pulls/NUMBER/commits"
    gh api --paginate "repos/ORG/REPO/pulls/NUMBER/reviews"
    gh api --paginate "repos/ORG/REPO/deployments?environment=production"

Incidents usually come from the change or incident system, joined to a commit by the
deploy that preceded them.

## Limits you should know

- **Tested against hand-written logs.** The test suite builds repos and attaches logs
  written to the published standard. It has not been run against logs produced by the
  Git AI CLI itself. Validate on one real repo before trusting the numbers.
- **Attribution only exists where the CLI is installed** and the agent reports its edits.
  Low coverage makes every other number unrepresentative.
- **"Generated" is not in git.** Notes record committed lines. The first funnel stage
  needs agent telemetry loaded through `generated.jsonl`.
- **Squash and rebase merges in the web UI** drop logs unless a CI job rewrites them.
  Git AI ships a CI workflow for this; without it, squash-merged work shows as `no_note`.
- **Survival is measured at snapshot time**, not at exactly day 30 or 90, and `git blame`
  follows whole-file renames only. Blame over a very large repo is slow; schedule it weekly.
- **Scale.** Ingest runs one `git show` per new commit and stores rows one at a time.
  Fine for a pilot of tens of repos; batch it before org-wide use.

## Layout

    schema.sql            tables and views (one file for both backends)
    aiattr/db.py          Postgres and SQLite behind one interface, plus copy-db
    aiattr/notes.py       authorship log parser
    aiattr/gitutil.py     read-only git helpers
    aiattr/ingest.py      commits, logs, deploy linking
    aiattr/survival.py    blame-based survival snapshots
    aiattr/imports.py     JSONL importers
    aiattr/metrics.py     every metric, one SQL query each
    aiattr/api.py         FastAPI endpoints (docs at /api/docs)
    dashboard/index.html  single-page dashboard
    tests/                demo repo builder and end-to-end tests
