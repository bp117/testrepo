-- AI attribution platform schema. Works on PostgreSQL 14+ and SQLite 3.35+.
-- {{PK}} and {{TS}} are filled in per backend by aiattr/db.py.

CREATE TABLE IF NOT EXISTS repos (
    id             {{PK}},
    name           text NOT NULL UNIQUE,
    team           text NOT NULL DEFAULT 'unassigned',
    default_branch text NOT NULL
);

-- One row per commit reachable from any branch, remote branch or PR head.
CREATE TABLE IF NOT EXISTS commits (
    repo_id           int  NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    sha               text NOT NULL,
    author_hash       text NOT NULL,          -- salted hash, never the raw email
    committed_at      {{TS}} NOT NULL,
    is_merge          boolean NOT NULL,
    on_default        boolean NOT NULL DEFAULT false,
    added_lines       int  NOT NULL DEFAULT 0,
    deleted_lines     int  NOT NULL DEFAULT 0,
    has_note          boolean NOT NULL DEFAULT false,  -- a Git AI authorship log exists
    git_ai_version    text,
    reverts_sha       text,                   -- set when this commit is a `git revert`
    first_deployed_at {{TS}},
    PRIMARY KEY (repo_id, sha)
);
CREATE INDEX IF NOT EXISTS commits_time ON commits (repo_id, committed_at);
CREATE INDEX IF NOT EXISTS commits_reverts ON commits (repo_id, reverts_sha);

-- Added lines of each commit, split by who wrote them.
--   ai        : attested to an AI session in the authorship log
--   human     : attested to a known human (IDE extension saw them typed)
--   untracked : commit has a log, but these lines have no attestation
--   no_note   : commit has no authorship log at all (provenance unknown)
CREATE TABLE IF NOT EXISTS commit_attribution (
    repo_id int  NOT NULL,
    sha     text NOT NULL,
    kind    text NOT NULL CHECK (kind IN ('ai','human','untracked','no_note')),
    tool    text NOT NULL DEFAULT '',
    model   text NOT NULL DEFAULT '',
    lines   int  NOT NULL,
    PRIMARY KEY (repo_id, sha, kind, tool, model),
    FOREIGN KEY (repo_id, sha) REFERENCES commits(repo_id, sha) ON DELETE CASCADE
);

-- Raw attested line ranges from each log, used to classify `git blame` output.
CREATE TABLE IF NOT EXISTS attribution_ranges (
    repo_id     int  NOT NULL,
    sha         text NOT NULL,
    file        text NOT NULL,
    start_line  int  NOT NULL,
    end_line    int  NOT NULL,
    kind        text NOT NULL,
    tool        text NOT NULL DEFAULT '',
    model       text NOT NULL DEFAULT '',
    session_key text NOT NULL,
    FOREIGN KEY (repo_id, sha) REFERENCES commits(repo_id, sha) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ranges_lookup ON attribution_ranges (repo_id, sha, file);

-- AI sessions named in each log.
CREATE TABLE IF NOT EXISTS note_sessions (
    repo_id          int  NOT NULL,
    sha              text NOT NULL,
    session_key      text NOT NULL,
    format           text NOT NULL CHECK (format IN ('session','legacy')),
    tool             text NOT NULL,
    model            text NOT NULL,
    human_hash       text,
    total_additions  int,     -- legacy logs only
    accepted_lines   int,     -- legacy logs only
    overridden_lines int,     -- legacy logs only
    PRIMARY KEY (repo_id, sha, session_key),
    FOREIGN KEY (repo_id, sha) REFERENCES commits(repo_id, sha) ON DELETE CASCADE
);

-- A survival snapshot is one `git blame` pass over the default branch head.
CREATE TABLE IF NOT EXISTS survival_snapshots (
    id       {{PK}},
    repo_id  int NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    head_sha text NOT NULL,
    taken_at {{TS}} NOT NULL
);
CREATE TABLE IF NOT EXISTS line_survival (
    snapshot_id     int  NOT NULL REFERENCES survival_snapshots(id) ON DELETE CASCADE,
    origin_sha      text NOT NULL,
    kind            text NOT NULL,
    tool            text NOT NULL DEFAULT '',
    model           text NOT NULL DEFAULT '',
    surviving_lines int  NOT NULL,
    PRIMARY KEY (snapshot_id, origin_sha, kind, tool, model)
);

-- Source-control and delivery events, imported from JSONL.
CREATE TABLE IF NOT EXISTS pull_requests (
    repo_id          int NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    number           int NOT NULL,
    author_hash      text,
    created_at       {{TS}} NOT NULL,
    first_review_at  {{TS}},
    merged_at        {{TS}},
    merge_commit_sha text,
    state            text NOT NULL DEFAULT 'open',
    PRIMARY KEY (repo_id, number)
);
CREATE TABLE IF NOT EXISTS pr_commits (
    repo_id int  NOT NULL,
    number  int  NOT NULL,
    sha     text NOT NULL,
    PRIMARY KEY (repo_id, number, sha),
    FOREIGN KEY (repo_id, number) REFERENCES pull_requests(repo_id, number) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS deployments (
    repo_id     int  NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    sha         text NOT NULL,
    environment text NOT NULL,
    deployed_at {{TS}} NOT NULL,
    status      text NOT NULL DEFAULT 'success',
    PRIMARY KEY (repo_id, sha, environment, deployed_at)
);
CREATE TABLE IF NOT EXISTS incidents (
    repo_id       int  NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    ref           text NOT NULL,              -- incident or change ticket id
    kind          text NOT NULL DEFAULT 'incident',
    caused_by_sha text NOT NULL,
    opened_at     {{TS}} NOT NULL,
    PRIMARY KEY (repo_id, ref)
);
-- Optional: lines agents generated, from agent telemetry (not in git notes).
CREATE TABLE IF NOT EXISTS agent_generated (
    repo_id         int  NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    day             date NOT NULL,
    tool            text NOT NULL,
    model           text NOT NULL DEFAULT '',
    generated_lines int  NOT NULL,
    PRIMARY KEY (repo_id, day, tool, model)
);

DROP VIEW IF EXISTS v_pr_lines;
DROP VIEW IF EXISTS v_pr_effective_commits;
DROP VIEW IF EXISTS v_failed_commits;
DROP VIEW IF EXISTS v_commit_lines;

-- Per non-merge commit: added lines split by author kind.
CREATE VIEW v_commit_lines AS
SELECT c.repo_id, c.sha, c.committed_at, c.on_default, c.has_note,
       c.first_deployed_at, c.added_lines,
       COALESCE(SUM(a.lines) FILTER (WHERE a.kind = 'ai'), 0)        AS ai_lines,
       COALESCE(SUM(a.lines) FILTER (WHERE a.kind = 'human'), 0)     AS human_lines,
       COALESCE(SUM(a.lines) FILTER (WHERE a.kind = 'untracked'), 0) AS untracked_lines
FROM commits c
LEFT JOIN commit_attribution a ON a.repo_id = c.repo_id AND a.sha = c.sha
WHERE NOT c.is_merge
GROUP BY c.repo_id, c.sha;

-- A commit "failed" if it was later reverted on the default branch,
-- or an incident/rollback record names it as the cause.
CREATE VIEW v_failed_commits AS
SELECT DISTINCT r.repo_id, r.reverts_sha AS sha
FROM commits r
WHERE r.reverts_sha IS NOT NULL AND r.on_default
UNION
SELECT DISTINCT i.repo_id, i.caused_by_sha FROM incidents i;

-- Commits that count toward a PR: its listed commits when we ingested them,
-- otherwise the merge commit (squash merges where branch commits are gone).
CREATE VIEW v_pr_effective_commits AS
SELECT pc.repo_id, pc.number, pc.sha
FROM pr_commits pc
JOIN commits c ON c.repo_id = pc.repo_id AND c.sha = pc.sha AND NOT c.is_merge
UNION
SELECT p.repo_id, p.number, p.merge_commit_sha
FROM pull_requests p
WHERE p.merge_commit_sha IS NOT NULL
  AND NOT EXISTS (
      SELECT 1 FROM pr_commits pc
      JOIN commits c ON c.repo_id = pc.repo_id AND c.sha = pc.sha AND NOT c.is_merge
      WHERE pc.repo_id = p.repo_id AND pc.number = p.number);

CREATE VIEW v_pr_lines AS
SELECT p.repo_id, p.number, p.created_at, p.first_review_at, p.merged_at,
       COALESCE(SUM(v.added_lines), 0) AS added_lines,
       COALESCE(SUM(v.ai_lines), 0)    AS ai_lines,
       COALESCE(MAX(CASE WHEN v.has_note THEN 1 ELSE 0 END), 0) AS has_note,
       (SELECT c.first_deployed_at FROM commits c
         WHERE c.repo_id = p.repo_id AND c.sha = p.merge_commit_sha) AS deployed_at,
       (EXISTS (SELECT 1 FROM v_failed_commits f
                 WHERE f.repo_id = p.repo_id AND f.sha = p.merge_commit_sha)
        OR EXISTS (SELECT 1 FROM pr_commits pc
                   JOIN v_failed_commits f ON f.repo_id = pc.repo_id AND f.sha = pc.sha
                   WHERE pc.repo_id = p.repo_id AND pc.number = p.number)) AS failed
FROM pull_requests p
LEFT JOIN v_pr_effective_commits e ON e.repo_id = p.repo_id AND e.number = p.number
LEFT JOIN v_commit_lines v ON v.repo_id = e.repo_id AND v.sha = e.sha
GROUP BY p.repo_id, p.number;
