"""Build two small git repos with hand-written Git AI authorship logs.

The logs follow Git AI Standard v3.0.0 and are attached under refs/notes/ai,
exactly where the Git AI CLI puts them. They are written by this script, not
by the CLI, so the numbers are known in advance and the pipeline can be
checked against them.

Usage:  python tests/build_demo.py <output-dir>
Writes: <dir>/payments-api, <dir>/platform-core, <dir>/*.jsonl, <dir>/config.yaml
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

NOW = datetime.now(timezone.utc).replace(microsecond=0)


def ago(days: float, hours: float = 0) -> str:
    return (NOW - timedelta(days=days, hours=hours)).isoformat()


def git(repo: Path, *args: str, date: str | None = None, email: str = "dev1@example.com") -> str:
    env = dict(os.environ, GIT_AUTHOR_NAME="Dev", GIT_AUTHOR_EMAIL=email,
               GIT_COMMITTER_NAME="Dev", GIT_COMMITTER_EMAIL=email)
    if date:
        env["GIT_AUTHOR_DATE"] = env["GIT_COMMITTER_DATE"] = date
    out = subprocess.run(["git", "-C", str(repo), *args], env=env, check=True,
                         capture_output=True, text=True)
    return out.stdout.strip()


def lines(prefix: str, n: int) -> str:
    return "".join(f"{prefix} line {i}\n" for i in range(1, n + 1))


def commit(repo: Path, msg: str, days: float, note: str | None = None, **kw) -> str:
    git(repo, "add", "-A")
    git(repo, "commit", "-q", "-m", msg, date=ago(days), **kw)
    sha = git(repo, "rev-parse", "HEAD")
    if note is not None:
        git(repo, "notes", "--ref=ai", "add", "-m", note, sha)
    return sha


def note(attestation: str, meta: dict) -> str:
    meta = {"schema_version": "authorship/3.0.0", "git_ai_version": "1.4.5",
            "base_commit_sha": "0" * 40, "prompts": {}, **meta}
    return attestation.rstrip("\n") + "\n---\n" + json.dumps(meta, indent=2)


def session(tool: str, model: str) -> dict:
    return {"agent_id": {"tool": tool, "id": f"conv-{tool}", "model": model},
            "human_author": "dev1@example.com"}


def build(out: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)

    # ---------------- payments-api ----------------
    pay = out / "payments-api"
    pay.mkdir()
    git(pay, "init", "-q", "-b", "main")

    # c1, 120 days ago: 20 lines, first 10 by Copilot (legacy-format log).
    (pay / "app.py").write_text(lines("app", 20))
    c1 = commit(pay, "Add app", 120, note(
        "app.py\n  abcd1234abcd1234 1-10",
        {"prompts": {"abcd1234abcd1234": {
            "agent_id": {"tool": "copilot", "id": "old", "model": "gpt-4.1"},
            "human_author": "Dev <dev1@example.com>", "total_additions": 14,
            "total_deletions": 0, "accepted_lines": 10, "overriden_lines": 0}}}))

    # c2, 100 days ago: 30 lines, all by Claude Code (session-format log).
    (pay / "util.py").write_text(lines("util", 30))
    c2 = commit(pay, "Add util", 100, note(
        "util.py\n  s_aaaaaaaaaaaaaa::t_11111111111111 1-20\n  s_aaaaaaaaaaaaaa::t_22222222222222 21-30",
        {"sessions": {"s_aaaaaaaaaaaaaa": session("claude", "claude-sonnet-4-5")}}))

    # c3, 60 days ago: a human rewrites the first 5 Copilot lines.
    body = (pay / "app.py").read_text().splitlines(keepends=True)
    body[:5] = [f"rewritten by hand {i}\n" for i in range(1, 6)]
    (pay / "app.py").write_text("".join(body))
    c3 = commit(pay, "Rewrite head of app", 60, note(
        "app.py\n  h_31dce776f88375 1-5",
        {"humans": {"h_31dce776f88375": {"author": "Dev <dev1@example.com>"}}}))

    # c4, 20 days ago: 8 lines of docs, no authorship log at all.
    (pay / "docs.md").write_text(lines("doc", 8))
    c4 = commit(pay, "Add docs", 20, email="dev2@example.com")

    # c5, 10 days ago: 40 lines, 36 by Cursor, 4 with no attestation.
    (pay / "feature.py").write_text(lines("feature", 40))
    c5 = commit(pay, "Add feature", 10, note(
        "feature.py\n  s_bbbbbbbbbbbbbb::t_33333333333333 1-36",
        {"sessions": {"s_bbbbbbbbbbbbbb": session("cursor", "gpt-5")}}))

    # c6, 5 days ago: the feature is reverted.
    git(pay, "revert", "--no-edit", c5, date=ago(5))
    c6 = git(pay, "rev-parse", "HEAD")

    # c7: unmerged branch with 12 AI lines.
    git(pay, "checkout", "-q", "-b", "wip")
    (pay / "wip.py").write_text(lines("wip", 12))
    c7 = commit(pay, "WIP", 2, note(
        "wip.py\n  s_aaaaaaaaaaaaaa::t_44444444444444 1-12",
        {"sessions": {"s_aaaaaaaaaaaaaa": session("claude", "claude-sonnet-4-5")}}))
    git(pay, "checkout", "-q", "main")

    # ---------------- platform-core ----------------
    plat = out / "platform-core"
    plat.mkdir()
    git(plat, "init", "-q", "-b", "main")
    (plat / "core.py").write_text(lines("core", 50))
    p1 = commit(plat, "Add core", 40, note(
        "core.py\n  s_cccccccccccccc::t_55555555555555 1-50",
        {"sessions": {"s_cccccccccccccc": session("copilot", "gpt-5")}}))

    # ---------------- SCM and delivery events ----------------
    def jsonl(name: str, rows: list[dict]) -> None:
        (out / name).write_text("".join(json.dumps(r) + "\n" for r in rows))

    jsonl("prs.jsonl", [
        {"repo": "payments-api", "number": 1, "author": "dev1@example.com",
         "created_at": ago(101), "first_review_at": ago(101, -4), "merged_at": ago(100),
         "merge_commit_sha": c2, "commits": [c2]},
        {"repo": "payments-api", "number": 2, "author": "dev2@example.com",
         "created_at": ago(22), "first_review_at": ago(21), "merged_at": ago(20),
         "merge_commit_sha": c4, "commits": [c4]},
        {"repo": "payments-api", "number": 3, "author": "dev1@example.com",
         "created_at": ago(11), "first_review_at": ago(11, -2), "merged_at": ago(10),
         "merge_commit_sha": c5, "commits": [c5]},
        {"repo": "platform-core", "number": 1, "author": "dev3@example.com",
         "created_at": ago(41), "first_review_at": ago(41, -6), "merged_at": ago(40),
         "merge_commit_sha": p1, "commits": [p1]},
    ])
    jsonl("deployments.jsonl", [
        {"repo": "payments-api", "sha": c3, "environment": "production", "deployed_at": ago(59)},
        {"repo": "payments-api", "sha": c6, "environment": "production", "deployed_at": ago(4)},
        {"repo": "platform-core", "sha": p1, "environment": "production", "deployed_at": ago(39)},
    ])
    jsonl("incidents.jsonl", [])
    jsonl("generated.jsonl", [
        {"repo": "payments-api", "day": ago(10)[:10], "tool": "cursor", "model": "gpt-5",
         "generated_lines": 300},
    ])
    (out / "config.yaml").write_text(
        f"database_url: sqlite:///{out / 'aiattr.db'}\n"
        "author_salt: demo-salt-change-me\n"
        "production_environment: production\n"
        "repos:\n"
        f"  - {{name: payments-api, path: {pay}, team: Payments, default_branch: main}}\n"
        f"  - {{name: platform-core, path: {plat}, team: Platform, default_branch: main}}\n")
    return {"c1": c1, "c2": c2, "c3": c3, "c4": c4, "c5": c5, "c6": c6, "c7": c7, "p1": p1}


if __name__ == "__main__":
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "demo-data").resolve()
    print(json.dumps(build(target), indent=2))
