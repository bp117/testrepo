"""End-to-end check: build the demo repos, run the pipeline against Postgres,
and compare every metric with numbers worked out by hand in build_demo.py.

Runs on SQLite always. To run the same checks on Postgres too, set
    TEST_DATABASE_URL=postgresql://aiattr:aiattr@localhost:5432/aiattr pytest
All tables are dropped and recreated in that database.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from aiattr import config, db, imports, ingest, metrics, survival  # noqa: E402
from aiattr.notes import parse_line_ranges, parse_note  # noqa: E402
import build_demo  # noqa: E402

DB = os.environ.get("TEST_DATABASE_URL")


def test_parse_line_ranges():
    assert parse_line_ranges("1-4,9,12-13") == [(1, 4), (9, 9), (12, 13)]
    assert parse_line_ranges("x,3,5-2") == [(3, 3)]


def test_parse_note_mixed_formats():
    text = (
        'src/main.rs\n'
        '  s_c9883b05a2487d::t_9f8e7d6c5b4a32 1-10\n'
        '  h_31dce776f88375 15-20\n'
        '"src/my file.rs"\n'
        '  abcd1234abcd1234 1-50\n'
        '---\n'
        '{"schema_version":"authorship/3.0.0","git_ai_version":"1.4.5",'
        '"prompts":{"abcd1234abcd1234":{"agent_id":{"tool":"cursor","id":"x","model":"gpt-4"},'
        '"total_additions":50,"accepted_lines":50,"overriden_lines":0}},'
        '"humans":{"h_31dce776f88375":{"author":"Dev <dev@example.com>"}},'
        '"sessions":{"s_c9883b05a2487d":{"agent_id":{"tool":"claude","id":"c","model":"sonnet"}}}}'
    )
    log = parse_note(text)
    assert log.schema_version == "authorship/3.0.0"
    got = [(r.file, r.start, r.end, r.author.kind, r.author.tool) for r in log.ranges]
    assert got == [
        ("src/main.rs", 1, 10, "ai", "claude"),
        ("src/main.rs", 15, 20, "human", ""),
        ("src/my file.rs", 1, 50, "ai", "cursor"),
    ]
    assert log.authors["abcd1234abcd1234"].total_additions == 50


def test_parse_note_tolerates_garbage():
    assert parse_note("not a log at all").ranges == []
    assert parse_note("a.py\n  s_x::t_y 1-3\n---\n{broken").ranges[0].author.tool == "unknown"


BACKENDS = ["sqlite"] + (["postgres"] if DB else [])


@pytest.fixture(scope="module", params=BACKENDS)
def demo(request, tmp_path_factory):
    out = tmp_path_factory.mktemp("demo")
    shas = build_demo.build(out)
    cfg = yaml.safe_load((out / "config.yaml").read_text())
    if request.param == "sqlite":
        conn = db.connect(f"sqlite:///{out / 'aiattr.db'}")
    else:
        conn = db.connect(DB)
        conn.script("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    config.init_db(conn)
    salt = cfg["author_salt"]
    for repo in cfg["repos"]:
        ingest.ingest_repo(conn, repo, salt)
    imports.import_prs(conn, str(out / "prs.jsonl"), salt)
    imports.import_deployments(conn, str(out / "deployments.jsonl"))
    imports.import_incidents(conn, str(out / "incidents.jsonl"))
    imports.import_generated(conn, str(out / "generated.jsonl"))
    for repo in cfg["repos"]:
        ingest.link_deployments(conn, repo, "production")
        survival.take_snapshot(conn, repo)
    conn.commit()
    yield conn, cfg, shas
    conn.close()


def test_copy_database_gives_identical_metrics(demo, tmp_path):
    """SQLite now, Postgres later: copying must not change a single number."""
    src, _, _ = demo
    targets = [f"sqlite:///{tmp_path / 'copy.db'}"]
    if DB and src.dialect == "sqlite":
        targets.append(DB)
    for url in targets:
        dst = db.connect(url)
        if dst.dialect == "postgres":
            dst.script("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
        counts = db.copy_database(src, dst)
        assert counts["commits"] == 8 and counts["repos"] == 2
        a, b = metrics.dashboard(src, None, 365), metrics.dashboard(dst, None, 365)
        a.pop("backend"), b.pop("backend")
        assert a == b
        with pytest.raises(SystemExit):
            db.copy_database(src, dst)          # refuses a non-empty destination
        dst.close()


def test_commit_classification(demo):
    conn, _, shas = demo
    rows = conn.execute(
        """SELECT c.sha, a.kind, a.tool, a.lines FROM commit_attribution a
           JOIN commits c USING (repo_id, sha) JOIN repos r ON r.id = c.repo_id
           WHERE r.name = 'payments-api'""").fetchall()
    got = {(sha, kind, tool): n for sha, kind, tool, n in rows}
    assert got[(shas["c1"], "ai", "copilot")] == 10
    assert got[(shas["c1"], "untracked", "")] == 10
    assert got[(shas["c2"], "ai", "claude")] == 30
    assert got[(shas["c3"], "human", "")] == 5
    assert got[(shas["c4"], "no_note", "")] == 8
    assert got[(shas["c5"], "ai", "cursor")] == 36
    assert got[(shas["c5"], "untracked", "")] == 4
    assert got[(shas["c7"], "ai", "claude")] == 12
    # parts always sum to the diff's added lines
    for sha, added in conn.execute(
            """SELECT c.sha, c.added_lines FROM commits c JOIN repos r ON r.id = c.repo_id
               WHERE r.name = 'payments-api' AND NOT c.is_merge"""):
        assert added == sum(n for (s, _, _), n in got.items() if s == sha)


def test_share_and_coverage(demo):
    conn, _, _ = demo
    s = metrics.share(conn, "Payments", days=365)
    assert s["commits"] == 6 and s["attributed_commits"] == 4
    assert s["coverage_pct"] == 66.7
    assert s["attributed_lines"] == 95 and s["ai_lines"] == 76
    assert s["ai_share_pct"] == 80.0
    everyone = metrics.share(conn, None, days=365)
    assert everyone["ai_lines"] == 126 and everyone["commits"] == 7


def test_survival(demo):
    conn, _, _ = demo
    s90 = metrics.survival(conn, "Payments", 90)
    # c1 (10 AI, 5 later rewritten) + c2 (30 AI): 35 of 40 still present
    assert s90["ai"] == {"added_lines": 40, "surviving_lines": 35, "survival_pct": 87.5}
    assert s90["non_ai"] == {"added_lines": 10, "surviving_lines": 10, "survival_pct": 100.0}
    s30 = metrics.survival(conn, "Payments", 30)
    assert s30["ai"]["survival_pct"] == 87.5
    assert s30["non_ai"] == {"added_lines": 15, "surviving_lines": 15, "survival_pct": 100.0}
    # the reverted Cursor commit: nothing survives
    s1 = metrics.survival(conn, "Payments", 1)
    assert s1["ai"] == {"added_lines": 76, "surviving_lines": 35, "survival_pct": 46.1}


def test_funnel(demo):
    conn, _, _ = demo
    stages = {s["stage"]: s["lines"] for s in metrics.funnel(conn, "Payments", 365)["stages"]}
    assert stages == {
        "Generated by agents": 300,
        "Committed": 88,                 # 76 merged + 12 on the unmerged branch
        "Merged to default branch": 76,
        "Deployed to production": 76,
        "Still in the codebase": 35,
    }


def test_agents(demo):
    conn, _, _ = demo
    rows = {r["tool"]: r for r in metrics.agents(conn, "Payments", 365)}
    assert rows["cursor"]["ai_lines"] == 36 and rows["cursor"]["failed_pct"] == 100.0
    assert rows["claude"]["ai_lines"] == 30 and rows["claude"]["failed_pct"] == 0.0
    assert rows["claude"]["survival_pct"] == 100.0
    assert rows["copilot"]["ai_lines"] == 10 and rows["copilot"]["survival_pct"] == 50.0
    assert rows["cursor"]["survival_pct"] is None      # too recent for the 30-day cohort
    assert rows["claude"]["ai_only_commit_pct"] == 100.0


def test_flow(demo):
    conn, _, _ = demo
    rows = {r["bucket"]: r for r in metrics.flow(conn, "Payments", 365)}
    ai = rows["AI-majority (50% or more)"]
    assert ai["prs"] == 2 and ai["failed_prs"] == 1 and ai["change_failure_pct"] == 50.0
    assert ai["open_to_merge_h"] == 24.0
    none = rows["No attribution data"]
    assert none["prs"] == 1 and none["failed_prs"] == 0 and none["review_wait_h"] == 24.0


def test_scorecard_and_dashboard(demo):
    conn, _, _ = demo
    card = {r["team"]: r for r in metrics.scorecard(conn, 365)}
    assert card["Platform"]["ai_share_pct"] == 100.0
    assert card["Platform"]["ai_survival_30d_pct"] == 100.0
    assert card["Payments"]["change_failure_pct"] == 33.3
    d = metrics.dashboard(conn, None, 365)
    assert d["teams"] == ["Payments", "Platform"]


def test_reingest_is_idempotent_and_picks_up_late_notes(demo):
    conn, cfg, shas = demo
    repo = cfg["repos"][0]
    again = ingest.ingest_repo(conn, repo, cfg["author_salt"])
    assert again["new_commits"] == 0 and again["refreshed"] == 0
    # a log arrives later for the docs commit (as a CI rewrite would add it)
    note = build_demo.note("docs.md\n  s_dddddddddddddd::t_66666666666666 1-8",
                           {"sessions": {"s_dddddddddddddd": build_demo.session("copilot", "gpt-5")}})
    build_demo.git(Path(repo["path"]), "notes", "--ref=ai", "add", "-m", note, shas["c4"])
    again = ingest.ingest_repo(conn, repo, cfg["author_salt"])
    assert again["refreshed"] == 1
    s = metrics.share(conn, "Payments", days=365)
    assert s["attributed_commits"] == 5 and s["ai_lines"] == 84


def test_no_raw_emails_stored(demo):
    conn, _, _ = demo
    for table, col in (("commits", "author_hash"), ("note_sessions", "human_hash"),
                       ("pull_requests", "author_hash")):
        vals = [r[0] for r in conn.execute(f"SELECT {col} FROM {table} WHERE {col} IS NOT NULL")]
        assert vals and all("@" not in v for v in vals)
