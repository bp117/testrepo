"""Read-only HTTP API and dashboard.  Run with:  python -m aiattr serve"""
from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI, Query
from fastapi.responses import FileResponse

from . import db, metrics

app = FastAPI(title="AI attribution platform", docs_url="/api/docs", redoc_url=None)
DASHBOARD = Path(__file__).resolve().parent.parent / "dashboard" / "index.html"


def _conn():
    return db.connect(os.environ["DATABASE_URL"])


@app.get("/")
def index():
    return FileResponse(DASHBOARD)


@app.get("/api/dashboard")
def dashboard(team: str | None = None, days: int = Query(90, ge=7, le=730)):
    with _conn() as conn:
        return metrics.dashboard(conn, team or None, days)


@app.get("/api/share")
def share(team: str | None = None, days: int = Query(90, ge=7, le=730)):
    with _conn() as conn:
        return metrics.share(conn, team or None, days)


@app.get("/api/survival")
def survival(team: str | None = None, min_age_days: int = Query(90, ge=1, le=730)):
    with _conn() as conn:
        return metrics.survival(conn, team or None, min_age_days)


@app.get("/api/funnel")
def funnel(team: str | None = None, days: int = Query(90, ge=7, le=730)):
    with _conn() as conn:
        return metrics.funnel(conn, team or None, days)


@app.get("/api/agents")
def agents(team: str | None = None, days: int = Query(90, ge=7, le=730)):
    with _conn() as conn:
        return metrics.agents(conn, team or None, days)


@app.get("/api/flow")
def flow(team: str | None = None, days: int = Query(90, ge=7, le=730)):
    with _conn() as conn:
        return metrics.flow(conn, team or None, days)


@app.get("/api/scorecard")
def scorecard(days: int = Query(90, ge=7, le=730)):
    with _conn() as conn:
        return metrics.scorecard(conn, days)
