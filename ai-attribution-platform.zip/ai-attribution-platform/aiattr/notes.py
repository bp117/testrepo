"""Parser for Git AI authorship logs (Git AI Standard v3.0.0).

A log is stored as a git note under refs/notes/ai. It has two sections split
by a line containing exactly `---`:

    src/main.rs
      s_c9883b05a2487d::t_9f8e7d6c5b4a32 1-10,15-20
      h_31dce776f88375 42-50
    ---
    { "schema_version": "authorship/3.0.0", "sessions": {...}, ... }

Attestation keys come in three forms:
    s_<hex>::t_<hex>  AI session          -> metadata.sessions[s_<hex>]
    h_<hex>           known human         -> metadata.humans[h_<hex>]
    <16 hex>          legacy AI session   -> metadata.prompts[<hex>]
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field

NOTES_REF = "refs/notes/ai"


@dataclass(frozen=True)
class Author:
    key: str                 # session id, human hash, or legacy hash
    kind: str                # 'ai' or 'human'
    format: str              # 'session', 'legacy' or 'human'
    tool: str = ""
    model: str = ""
    human_author: str | None = None
    total_additions: int | None = None
    accepted_lines: int | None = None
    overridden_lines: int | None = None


@dataclass(frozen=True)
class AttestedRange:
    file: str
    start: int
    end: int
    author: Author


@dataclass
class AuthorshipLog:
    schema_version: str | None = None
    git_ai_version: str | None = None
    ranges: list[AttestedRange] = field(default_factory=list)
    authors: dict[str, Author] = field(default_factory=dict)

    @property
    def ai_sessions(self) -> list[Author]:
        return [a for a in self.authors.values() if a.kind == "ai"]


def parse_line_ranges(spec: str) -> list[tuple[int, int]]:
    """'1-4,9,12-13' -> [(1, 4), (9, 9), (12, 13)]. Malformed parts are skipped."""
    out: list[tuple[int, int]] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            if "-" in part:
                a, b = part.split("-", 1)
                start, end = int(a), int(b)
            else:
                start = end = int(part)
        except ValueError:
            continue
        if start >= 1 and end >= start:
            out.append((start, end))
    return out


def _agent(rec: dict) -> tuple[str, str]:
    agent = rec.get("agent_id") or {}
    return str(agent.get("tool") or "unknown"), str(agent.get("model") or "unknown")


def _resolve(key: str, meta: dict) -> Author:
    sessions = meta.get("sessions") or {}
    humans = meta.get("humans") or {}
    prompts = meta.get("prompts") or {}

    if key.startswith("s_"):
        sid = key.split("::", 1)[0]
        rec = sessions.get(sid) or {}
        tool, model = _agent(rec)
        return Author(sid, "ai", "session", tool, model, rec.get("human_author"))

    if key.startswith("h_"):
        rec = humans.get(key) or {}
        return Author(key, "human", "human", human_author=rec.get("author"))

    # Legacy key. Very old logs used 7-char hashes, so fall back to a prefix match.
    rec = prompts.get(key)
    full = key
    if rec is None:
        for k, v in prompts.items():
            if k.startswith(key) or key.startswith(k):
                rec, full = v, k
                break
    rec = rec or {}
    tool, model = _agent(rec)
    return Author(
        full, "ai", "legacy", tool, model, rec.get("human_author"),
        rec.get("total_additions"), rec.get("accepted_lines"),
        rec.get("overriden_lines"),  # sic: the standard spells it this way
    )


def parse_note(text: str) -> AuthorshipLog:
    """Parse one authorship log. Never raises on malformed input."""
    lines = text.splitlines()
    try:
        divider = lines.index("---")
    except ValueError:
        divider = len(lines)

    meta: dict = {}
    meta_text = "\n".join(lines[divider + 1:]).strip()
    if meta_text:
        try:
            loaded = json.loads(meta_text)
            if isinstance(loaded, dict):
                meta = loaded
        except json.JSONDecodeError:
            meta = {}

    log = AuthorshipLog(meta.get("schema_version"), meta.get("git_ai_version"))

    current_file: str | None = None
    for line in lines[:divider]:
        if not line.strip():
            continue
        if line.startswith("  "):
            if current_file is None:
                continue
            key, _, spec = line.strip().partition(" ")
            if not spec:
                continue
            author = log.authors.get(key.split("::", 1)[0] if key.startswith("s_") else key)
            if author is None:
                author = _resolve(key, meta)
                log.authors[author.key] = author
            for start, end in parse_line_ranges(spec):
                log.ranges.append(AttestedRange(current_file, start, end, author))
        else:
            path = line.strip()
            if len(path) >= 2 and path[0] == '"' and path[-1] == '"':
                path = path[1:-1]
            current_file = path

    # Sessions listed in metadata but with no surviving lines still count as sessions.
    for sid, rec in (meta.get("sessions") or {}).items():
        if sid not in log.authors and isinstance(rec, dict):
            tool, model = _agent(rec)
            log.authors[sid] = Author(sid, "ai", "session", tool, model, rec.get("human_author"))
    for pid, rec in (meta.get("prompts") or {}).items():
        if pid not in log.authors and isinstance(rec, dict):
            tool, model = _agent(rec)
            log.authors[pid] = Author(
                pid, "ai", "legacy", tool, model, rec.get("human_author"),
                rec.get("total_additions"), rec.get("accepted_lines"), rec.get("overriden_lines"))
    return log
