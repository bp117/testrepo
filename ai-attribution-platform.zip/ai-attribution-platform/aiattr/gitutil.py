"""Thin wrappers over the git CLI. Read-only: nothing here writes to a repo."""
from __future__ import annotations

import re
import subprocess

from .notes import NOTES_REF

EMPTY_TREE = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"
_HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
_REVERT = re.compile(r"This reverts commit ([0-9a-f]{40})")
_BLAME_HEAD = re.compile(r"^([0-9a-f]{40}) (\d+) (\d+)")


class GitError(RuntimeError):
    pass


def git(repo: str, *args: str, check: bool = True) -> str:
    proc = subprocess.run(
        ["git", "-c", "core.quotepath=off", "-C", repo, *args],
        capture_output=True,
    )
    if check and proc.returncode != 0:
        raise GitError(f"git {' '.join(args)}: {proc.stderr.decode(errors='replace').strip()}")
    return proc.stdout.decode("utf-8", errors="replace")


def fetch(repo: str) -> None:
    """Refresh a mirror clone (all refs, including refs/notes/ai)."""
    git(repo, "remote", "update", "--prune")


def resolve_default(repo: str, branch: str) -> str:
    for ref in (f"refs/heads/{branch}", f"refs/remotes/origin/{branch}"):
        out = git(repo, "rev-parse", "--verify", "--quiet", ref, check=False).strip()
        if out:
            return out
    raise GitError(f"default branch '{branch}' not found in {repo}")


def commits_with_notes(repo: str) -> set[str]:
    out = git(repo, "notes", f"--ref={NOTES_REF}", "list", check=False)
    return {parts[1] for parts in (ln.split() for ln in out.splitlines()) if len(parts) == 2}


def read_note(repo: str, sha: str) -> str:
    return git(repo, "notes", f"--ref={NOTES_REF}", "show", sha)


def list_commits(repo: str) -> list[dict]:
    """Every commit on a branch, remote branch or PR head (never the notes ref itself)."""
    fmt = "%H%x1f%P%x1f%ae%x1f%cI%x1f%B%x1e"
    out = git(repo, "log", f"--format={fmt}", "--branches", "--remotes",
              "--glob=refs/pull/*/head", check=False)
    commits = []
    for rec in out.split("\x1e"):
        rec = rec.strip("\n")
        if not rec:
            continue
        sha, parents, email, date, body = rec.split("\x1f", 4)
        m = _REVERT.search(body)
        commits.append({
            "sha": sha,
            "parents": parents.split(),
            "email": email,
            "committed_at": date,
            "reverts_sha": m.group(1) if m else None,
        })
    return commits


def reachable(repo: str, rev: str, *exclude: str) -> set[str]:
    args = ["rev-list", rev, *[f"^{x}" for x in exclude]]
    return set(git(repo, *args).split())


def added_lines(repo: str, sha: str) -> tuple[dict[str, list[tuple[int, int]]], int]:
    """Lines a non-merge commit added, as {file: [(start, end)]} in the commit's
    own line numbering, plus the count of deleted lines."""
    out = git(repo, "show", "--format=", "--unified=0", "--no-color", "--no-ext-diff", sha)
    added: dict[str, list[tuple[int, int]]] = {}
    deleted = 0
    current: str | None = None
    for line in out.splitlines():
        if line.startswith("+++ "):
            target = line[4:].rstrip("\t")
            current = target[2:] if target.startswith("b/") else None
        elif line.startswith("@@") and current is not None:
            m = _HUNK.match(line)
            if not m:
                continue
            deleted += int(m.group(2)) if m.group(2) is not None else 1
            count = int(m.group(4)) if m.group(4) is not None else 1
            if count:
                start = int(m.group(3))
                added.setdefault(current, []).append((start, start + count - 1))
    return added, deleted


def text_files(repo: str, rev: str) -> list[str]:
    """Non-binary files at a revision."""
    out = git(repo, "diff", "--numstat", "-z", "--no-renames", EMPTY_TREE, rev)
    files = []
    for rec in out.split("\0"):
        parts = rec.split("\t", 2)
        if len(parts) == 3 and parts[0] != "-":
            files.append(parts[2])
    return files


def blame_origins(repo: str, rev: str, path: str):
    """Yield (origin_sha, origin_file, origin_line) for every line of a file."""
    out = git(repo, "blame", "--line-porcelain", rev, "--", path, check=False)
    sha = orig_line = fname = None
    for line in out.split("\n"):
        if line.startswith("\t"):
            if sha is not None:
                yield sha, fname or path, orig_line
            sha = None
            continue
        m = _BLAME_HEAD.match(line)
        if m:
            sha, orig_line, fname = m.group(1), int(m.group(2)), None
        elif line.startswith("filename "):
            fname = line[9:]
