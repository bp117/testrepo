"""Config file loading and database connections."""
from __future__ import annotations

import os

import yaml

from . import db


def load(path: str | None) -> dict:
    path = path or os.environ.get("AIATTR_CONFIG", "config.yaml")
    with open(path, encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}
    cfg["database_url"] = os.environ.get("DATABASE_URL", cfg.get("database_url"))
    cfg["author_salt"] = os.environ.get("AIATTR_SALT", cfg.get("author_salt", ""))
    cfg.setdefault("production_environment", "production")
    cfg.setdefault("repos", [])
    if not cfg["database_url"]:
        raise SystemExit("database_url is not set (config file or DATABASE_URL)")
    if not cfg["author_salt"]:
        raise SystemExit("author_salt is not set (config file or AIATTR_SALT)")
    return cfg


def connect(cfg: dict) -> db.DB:
    return db.connect(cfg["database_url"])


def init_db(conn: db.DB) -> None:
    conn.init_schema()
