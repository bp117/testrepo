"""AI attribution platform: ingest Git AI authorship logs, derive delivery metrics."""
