"""Software-factory metrics derived from the attribution store.

Every function takes an optional `team` and a look-back window in `days`, and
returns plain dicts. Nothing here reports on an individual developer.

The SQL is kept to what PostgreSQL and SQLite both accept. Anything the two
disagree on (date bucketing, medians, interval arithmetic) is done in Python.
"""
from __future__ import annotations

from datetime import timedelta
from decimal import Decimal
from statistics import median

from . import db as dbm


def _pct(num, den):
    return round(100.0 * float(num) / float(den), 1) if den else None


def _plain(v):
    """Postgres numerics arrive as Decimal; hand back int or float."""
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    return v


def _rows(conn, sql: str, params: dict) -> list[dict]:
    res = conn.execute(sql, params)
    return [{c: _plain(v) for c, v in zip(res.columns, row)} for row in res.fetchall()]


def _scope(team, params: dict) -> str:
    if team is None:
        return "1 = 1"
    params["team"] = team
    return "r.team = %(team)s"


def _since(conn, days: int):
    return conn.ts(dbm.now() - timedelta(days=days))


def _hours(conn, start, end):
    a, b = conn.dt(start), conn.dt(end)
    return (b - a).total_seconds() / 3600.0 if a and b else None


def _median(values):
    values = [v for v in values if v is not None]
    return round(median(values), 1) if values else None


def _bucket(has_note, ai_lines, added_lines) -> str:
    if not has_note:
        return "No attribution data"
    if not ai_lines:
        return "No AI"
    return "AI-assisted (under 50%)" if ai_lines < 0.5 * added_lines else "AI-majority (50% or more)"


def teams(conn) -> list[str]:
    return [r[0] for r in conn.execute("SELECT DISTINCT team FROM repos ORDER BY 1")]


def share(conn, team=None, days=90) -> dict:
    """Attribution coverage and AI share of added lines on default branches."""
    p = {"since": _since(conn, days)}
    row = _rows(conn, f"""
        SELECT count(*)                                            AS commits,
               count(*) FILTER (WHERE c.has_note)                  AS attributed_commits,
               COALESCE(sum(c.added_lines), 0)                     AS added_lines,
               COALESCE(sum(c.added_lines) FILTER (WHERE c.has_note), 0) AS attributed_lines,
               COALESCE(sum(c.ai_lines), 0)                        AS ai_lines,
               COALESCE(sum(c.human_lines), 0)                     AS known_human_lines,
               COALESCE(sum(c.untracked_lines), 0)                 AS untracked_lines
        FROM v_commit_lines c JOIN repos r ON r.id = c.repo_id
        WHERE c.on_default AND {_scope(team, p)} AND c.committed_at >= %(since)s""", p)[0]
    row["coverage_pct"] = _pct(row["attributed_commits"], row["commits"])
    row["ai_share_pct"] = _pct(row["ai_lines"], row["attributed_lines"])
    return row


def weekly(conn, team=None, days=90) -> list[dict]:
    p = {"since": _since(conn, days)}
    rows = _rows(conn, f"""
        SELECT c.committed_at, c.has_note, c.added_lines, c.ai_lines
        FROM v_commit_lines c JOIN repos r ON r.id = c.repo_id
        WHERE c.on_default AND {_scope(team, p)} AND c.committed_at >= %(since)s""", p)
    weeks: dict[str, dict] = {}
    for r in rows:
        day = conn.dt(r["committed_at"]).date()
        key = (day - timedelta(days=day.weekday())).isoformat()   # Monday of that week, UTC
        w = weeks.setdefault(key, {"week": key, "commits": 0, "attributed_commits": 0,
                                   "attributed_lines": 0, "ai_lines": 0})
        w["commits"] += 1
        if r["has_note"]:
            w["attributed_commits"] += 1
            w["attributed_lines"] += r["added_lines"]
        w["ai_lines"] += r["ai_lines"]
    out = [weeks[k] for k in sorted(weeks)]
    for w in out:
        w["ai_share_pct"] = _pct(w["ai_lines"], w["attributed_lines"])
        w["coverage_pct"] = _pct(w["attributed_commits"], w["commits"])
    return out


def _latest_snapshots(conn, team) -> list[dict]:
    p: dict = {}
    return _rows(conn, f"""
        SELECT s.id, s.repo_id, s.taken_at
        FROM survival_snapshots s JOIN repos r ON r.id = s.repo_id
        WHERE {_scope(team, p)}
          AND s.id = (SELECT max(s2.id) FROM survival_snapshots s2 WHERE s2.repo_id = s.repo_id)""", p)


def _survival_raw(conn, team, min_age_days) -> dict[tuple[str, str, str], list[int]]:
    """{(kind, tool, model): [added, alive]} for commits at least min_age_days
    older than each repo's latest snapshot."""
    out: dict[tuple[str, str, str], list[int]] = {}
    for snap in _latest_snapshots(conn, team):
        p = {"repo": snap["repo_id"], "snap": snap["id"],
             "cutoff": conn.ts(conn.dt(snap["taken_at"]) - timedelta(days=min_age_days))}
        cohort = "c.repo_id = %(repo)s AND c.on_default AND NOT c.is_merge AND c.committed_at <= %(cutoff)s"
        for r in _rows(conn, f"""
                SELECT a.kind, a.tool, a.model, sum(a.lines) AS n
                FROM commits c JOIN commit_attribution a ON a.repo_id = c.repo_id AND a.sha = c.sha
                WHERE {cohort} AND a.kind <> 'no_note'
                GROUP BY a.kind, a.tool, a.model""", p):
            out.setdefault((r["kind"], r["tool"], r["model"]), [0, 0])[0] += r["n"]
        for r in _rows(conn, f"""
                SELECT l.kind, l.tool, l.model, sum(l.surviving_lines) AS n
                FROM commits c JOIN line_survival l ON l.origin_sha = c.sha
                WHERE l.snapshot_id = %(snap)s AND {cohort} AND l.kind <> 'no_note'
                GROUP BY l.kind, l.tool, l.model""", p):
            out.setdefault((r["kind"], r["tool"], r["model"]), [0, 0])[1] += r["n"]
    return out


def survival(conn, team=None, min_age_days=90) -> dict:
    """Of lines added by commits at least `min_age_days` old, the share still
    present on the default branch at the latest snapshot, AI vs everything else
    in attributed commits."""
    totals = {"ai": [0, 0], "non_ai": [0, 0]}
    for (kind, _, _), (added, alive) in _survival_raw(conn, team, min_age_days).items():
        t = totals["ai" if kind == "ai" else "non_ai"]
        t[0] += added
        t[1] += alive
    out = {"min_age_days": min_age_days}
    for name, (added, alive) in totals.items():
        out[name] = ({"added_lines": added, "surviving_lines": alive,
                      "survival_pct": _pct(alive, added)} if added else None)
    return out


def funnel(conn, team=None, days=90) -> dict:
    """AI lines at each stage from prompt to production.

    `generated` needs agent telemetry (agent_generated table); git notes only
    record what was committed. Committed counts merged work plus work on
    branches that are not part of an already-merged pull request."""
    p = {"since": _since(conn, days)}
    scope = _scope(team, p)
    row = _rows(conn, f"""
        SELECT COALESCE(sum(c.ai_lines) FILTER (WHERE c.on_default), 0) AS merged,
               COALESCE(sum(c.ai_lines) FILTER (WHERE c.on_default
                         AND c.first_deployed_at IS NOT NULL), 0)        AS deployed,
               COALESCE(sum(c.ai_lines) FILTER (WHERE NOT c.on_default AND NOT EXISTS (
                         SELECT 1 FROM pr_commits pc
                         JOIN pull_requests pr ON pr.repo_id = pc.repo_id AND pr.number = pc.number
                         WHERE pc.repo_id = c.repo_id AND pc.sha = c.sha
                           AND pr.merged_at IS NOT NULL)), 0)            AS unmerged
        FROM v_commit_lines c JOIN repos r ON r.id = c.repo_id
        WHERE {scope} AND c.committed_at >= %(since)s""", p)[0]
    surviving = _rows(conn, f"""
        SELECT COALESCE(sum(l.surviving_lines), 0) AS n
        FROM survival_snapshots s
        JOIN repos r ON r.id = s.repo_id
        JOIN line_survival l ON l.snapshot_id = s.id
        JOIN commits c ON c.repo_id = s.repo_id AND c.sha = l.origin_sha
        WHERE s.id = (SELECT max(s2.id) FROM survival_snapshots s2 WHERE s2.repo_id = s.repo_id)
          AND l.kind = 'ai' AND c.on_default AND {scope} AND c.committed_at >= %(since)s""", p)[0]["n"]
    gp = {"day": (dbm.now() - timedelta(days=days)).date().isoformat()}
    generated = _rows(conn, f"""
        SELECT sum(g.generated_lines) AS n
        FROM agent_generated g JOIN repos r ON r.id = g.repo_id
        WHERE {_scope(team, gp)} AND g.day >= %(day)s""", gp)[0]["n"]
    merged, deployed = int(row["merged"]), int(row["deployed"])
    stages = [
        {"stage": "Generated by agents", "lines": int(generated) if generated is not None else None},
        {"stage": "Committed", "lines": merged + int(row["unmerged"])},
        {"stage": "Merged to default branch", "lines": merged},
        {"stage": "Deployed to production", "lines": deployed},
        {"stage": "Still in the codebase", "lines": int(surviving)},
    ]
    return {"stages": stages}


def agents(conn, team=None, days=90, survival_age_days=30) -> list[dict]:
    """Per agent and model: volume, later-failed share and survival."""
    p = {"since": _since(conn, days)}
    rows = _rows(conn, f"""
        SELECT a.tool, a.model,
               sum(a.lines)                                               AS ai_lines,
               count(DISTINCT a.repo_id || ':' || a.sha)                  AS commits,
               COALESCE(sum(a.lines) FILTER (WHERE f.sha IS NOT NULL), 0) AS failed_lines,
               count(DISTINCT a.repo_id || ':' || a.sha) FILTER (
                   WHERE c.added_lines > 0 AND a.lines >= 0.9 * c.added_lines) AS ai_only_commits
        FROM commit_attribution a
        JOIN commits c ON c.repo_id = a.repo_id AND c.sha = a.sha
        JOIN repos r ON r.id = c.repo_id
        LEFT JOIN v_failed_commits f ON f.repo_id = c.repo_id AND f.sha = c.sha
        WHERE a.kind = 'ai' AND c.on_default AND {_scope(team, p)} AND c.committed_at >= %(since)s
        GROUP BY a.tool, a.model
        ORDER BY sum(a.lines) DESC, a.tool, a.model""", p)
    total = sum(int(r["ai_lines"]) for r in rows)
    surv = _survival_raw(conn, team, survival_age_days)
    for r in rows:
        r["ai_lines"], r["failed_lines"] = int(r["ai_lines"]), int(r["failed_lines"])
        r["share_of_ai_pct"] = _pct(r["ai_lines"], total)
        r["failed_pct"] = _pct(r["failed_lines"], r["ai_lines"])
        r["ai_only_commit_pct"] = _pct(r["ai_only_commits"], r["commits"])
        added, alive = surv.get(("ai", r["tool"], r["model"]), (0, 0))
        r["survival_pct"] = _pct(alive, added)
        r["survival_age_days"] = survival_age_days
    return rows


def flow(conn, team=None, days=90) -> list[dict]:
    """Merged pull requests grouped by how much of their code was AI-written."""
    p = {"since": _since(conn, days)}
    rows = _rows(conn, f"""
        SELECT p.created_at, p.first_review_at, p.merged_at, p.deployed_at,
               p.added_lines, p.ai_lines, p.has_note, p.failed
        FROM v_pr_lines p JOIN repos r ON r.id = p.repo_id
        WHERE p.merged_at IS NOT NULL AND {_scope(team, p)} AND p.merged_at >= %(since)s""", p)
    groups: dict[str, list[dict]] = {}
    for r in rows:
        groups.setdefault(_bucket(r["has_note"], r["ai_lines"], r["added_lines"]), []).append(r)
    out = []
    for bucket in sorted(groups):
        g = groups[bucket]
        failed = sum(1 for r in g if r["failed"])
        out.append({
            "bucket": bucket,
            "prs": len(g),
            "review_wait_h": _median(_hours(conn, r["created_at"], r["first_review_at"]) for r in g),
            "open_to_merge_h": _median(_hours(conn, r["created_at"], r["merged_at"]) for r in g),
            "merge_to_deploy_h": _median(_hours(conn, r["merged_at"], r["deployed_at"]) for r in g),
            "failed_prs": failed,
            "change_failure_pct": _pct(failed, len(g)),
        })
    return out


def commit_quality(conn, team=None, days=90) -> list[dict]:
    """Commit-level fallback when no pull request data is loaded: later-failed
    share and time to production, by AI share of the commit."""
    p = {"since": _since(conn, days)}
    rows = _rows(conn, f"""
        SELECT c.committed_at, c.first_deployed_at, c.has_note, c.ai_lines, c.added_lines,
               CASE WHEN f.sha IS NULL THEN 0 ELSE 1 END AS failed
        FROM v_commit_lines c JOIN repos r ON r.id = c.repo_id
        LEFT JOIN v_failed_commits f ON f.repo_id = c.repo_id AND f.sha = c.sha
        WHERE c.on_default AND c.added_lines > 0 AND {_scope(team, p)}
          AND c.committed_at >= %(since)s""", p)
    groups: dict[str, list[dict]] = {}
    for r in rows:
        groups.setdefault(_bucket(r["has_note"], r["ai_lines"], r["added_lines"]), []).append(r)
    out = []
    for bucket in sorted(groups):
        g = groups[bucket]
        failed = sum(r["failed"] for r in g)
        out.append({
            "bucket": bucket,
            "commits": len(g),
            "failed_commits": failed,
            "commit_to_deploy_h": _median(
                _hours(conn, r["committed_at"], r["first_deployed_at"]) for r in g),
            "failed_pct": _pct(failed, len(g)),
        })
    return out


def scorecard(conn, days=90) -> list[dict]:
    """One row per team. Team is the smallest unit this platform reports."""
    out = []
    for team in teams(conn):
        s = share(conn, team, days)
        sv = survival(conn, team, 30)
        prs = flow(conn, team, days)
        n = sum(r["prs"] for r in prs)
        failed = sum(r["failed_prs"] for r in prs)
        out.append({
            "team": team,
            "commits": s["commits"],
            "coverage_pct": s["coverage_pct"],
            "ai_share_pct": s["ai_share_pct"],
            "ai_survival_30d_pct": sv["ai"]["survival_pct"] if sv["ai"] else None,
            "merged_prs": n,
            "change_failure_pct": _pct(failed, n),
        })
    return out


def dashboard(conn, team=None, days=90) -> dict:
    return {
        "team": team, "days": days, "teams": teams(conn),
        "backend": conn.dialect,
        "share": share(conn, team, days),
        "weekly": weekly(conn, team, days),
        "survival_30d": survival(conn, team, 30),
        "survival_90d": survival(conn, team, 90),
        "funnel": funnel(conn, team, days),
        "agents": agents(conn, team, days),
        "flow": flow(conn, team, days),
        "commit_quality": commit_quality(conn, team, days),
        "scorecard": scorecard(conn, days),
    }
