"""Ingest commits and their Git AI authorship logs into Postgres."""
from __future__ import annotations

import hashlib

from . import gitutil
from .notes import parse_note


def author_hash(identity: str | None, salt: str) -> str | None:
    """Salted hash so the store never holds a raw email address."""
    if not identity:
        return None
    email = identity.strip().lower()
    if "<" in email and email.endswith(">"):
        email = email[email.rindex("<") + 1:-1]
    return hashlib.sha256((salt + email).encode()).hexdigest()[:16]


def upsert_repo(conn, name: str, team: str, default_branch: str) -> int:
    row = conn.execute(
        """INSERT INTO repos (name, team, default_branch) VALUES (%s, %s, %s)
           ON CONFLICT (name) DO UPDATE SET team = EXCLUDED.team,
                                            default_branch = EXCLUDED.default_branch
           RETURNING id""",
        (name, team, default_branch),
    ).fetchone()
    return row[0]


def classify(added: dict[str, list[tuple[int, int]]], log) -> dict[tuple[str, str, str], int]:
    """Split a commit's added lines into (kind, tool, model) -> line count.

    Only lines the commit actually added are counted, so the parts always sum
    to the diff's added-line total. `log` is None when the commit has no note.
    """
    total = sum(e - s + 1 for spans in added.values() for s, e in spans)
    if log is None:
        return {("no_note", "", ""): total} if total else {}

    counts: dict[tuple[str, str, str], int] = {}
    by_file: dict[str, list] = {}
    for r in log.ranges:
        by_file.setdefault(r.file, []).append(r)

    attested = 0
    for path, spans in added.items():
        ranges = by_file.get(path)
        if not ranges:
            continue
        remaining: set[int] = set()
        for s, e in spans:
            remaining.update(range(s, e + 1))
        for r in ranges:
            hit = {n for n in range(r.start, r.end + 1) if n in remaining}
            if not hit:
                continue
            remaining -= hit
            a = r.author
            key = (a.kind, a.tool, a.model) if a.kind == "ai" else ("human", "", "")
            counts[key] = counts.get(key, 0) + len(hit)
            attested += len(hit)
    if total - attested:
        counts[("untracked", "", "")] = total - attested
    return counts


def _store_commit(conn, repo_id: int, path: str, c: dict, has_note: bool, salt: str) -> None:
    sha = c["sha"]
    is_merge = len(c["parents"]) > 1
    added, deleted = ({}, 0) if is_merge else gitutil.added_lines(path, sha)
    log = parse_note(gitutil.read_note(path, sha)) if has_note else None
    total = sum(e - s + 1 for spans in added.values() for s, e in spans)

    conn.execute("DELETE FROM commits WHERE repo_id = %s AND sha = %s", (repo_id, sha))
    conn.execute(
        """INSERT INTO commits (repo_id, sha, author_hash, committed_at, is_merge,
                                added_lines, deleted_lines, has_note, git_ai_version, reverts_sha)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (repo_id, sha, author_hash(c["email"], salt) or "", conn.ts(c["committed_at"]), is_merge,
         total, deleted, has_note, log.git_ai_version if log else None, c["reverts_sha"]),
    )
    if is_merge:
        return

    for (kind, tool, model), lines in classify(added, log).items():
        conn.execute(
            "INSERT INTO commit_attribution VALUES (%s, %s, %s, %s, %s, %s)",
            (repo_id, sha, kind, tool, model, lines),
        )
    if log is None:
        return
    for r in log.ranges:
        a = r.author
        conn.execute(
            "INSERT INTO attribution_ranges VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (repo_id, sha, r.file, r.start, r.end, a.kind,
             a.tool if a.kind == "ai" else "", a.model if a.kind == "ai" else "", a.key),
        )
    for a in log.ai_sessions:
        conn.execute(
            """INSERT INTO note_sessions VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
               ON CONFLICT DO NOTHING""",
            (repo_id, sha, a.key, a.format, a.tool, a.model, author_hash(a.human_author, salt),
             a.total_additions, a.accepted_lines, a.overridden_lines),
        )


def ingest_repo(conn, cfg: dict, salt: str) -> dict:
    """Ingest one repo. Safe to re-run: new commits are added, and commits whose
    authorship log arrived later (for example from a CI rewrite) are refreshed."""
    path = cfg["path"]
    if cfg.get("fetch"):
        gitutil.fetch(path)
    repo_id = upsert_repo(conn, cfg["name"], cfg.get("team", "unassigned"),
                          cfg.get("default_branch", "main"))
    head = gitutil.resolve_default(path, cfg.get("default_branch", "main"))
    noted = gitutil.commits_with_notes(path)
    known = dict(conn.execute(
        "SELECT sha, has_note FROM commits WHERE repo_id = %s", (repo_id,)).fetchall())

    new = refreshed = 0
    for c in gitutil.list_commits(path):
        sha = c["sha"]
        has_note = sha in noted
        if sha not in known:
            new += 1
        elif has_note and not known[sha]:
            refreshed += 1
        else:
            continue
        _store_commit(conn, repo_id, path, c, has_note, salt)

    conn.execute("UPDATE commits SET on_default = %s WHERE repo_id = %s", (False, repo_id))
    conn.in_chunks("UPDATE commits SET on_default = %s WHERE repo_id = %s AND sha IN ({in})",
                   (True, repo_id), list(gitutil.reachable(path, head)))
    conn.commit()
    return {"repo": cfg["name"], "new_commits": new, "refreshed": refreshed, "head": head}


def link_deployments(conn, cfg: dict, environment: str) -> int:
    """Stamp each commit with the first successful deploy that contained it."""
    path = cfg["path"]
    row = conn.execute("SELECT id FROM repos WHERE name = %s", (cfg["name"],)).fetchone()
    if not row:
        return 0
    repo_id = row[0]
    deploys = conn.execute(
        """SELECT sha, deployed_at FROM deployments
           WHERE repo_id = %s AND environment = %s AND status = 'success'
           ORDER BY deployed_at""", (repo_id, environment)).fetchall()
    conn.execute("UPDATE commits SET first_deployed_at = NULL WHERE repo_id = %s", (repo_id,))
    stamped = 0
    previous: list[str] = []
    for sha, when in deploys:
        try:
            shas = list(gitutil.reachable(path, sha, *previous[-1:]))
        except gitutil.GitError:
            continue  # deploy of a commit this clone does not have
        stamped += conn.in_chunks(
            """UPDATE commits SET first_deployed_at = %s
               WHERE repo_id = %s AND first_deployed_at IS NULL AND sha IN ({in})""",
            (conn.ts(when), repo_id), shas)
        previous.append(sha)
    conn.commit()
    return stamped
