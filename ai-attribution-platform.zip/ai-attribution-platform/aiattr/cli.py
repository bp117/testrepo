"""Command line entry point:  python -m aiattr <command> [--config config.yaml]"""
from __future__ import annotations

import argparse
import json

from . import config, db, imports, ingest, metrics, survival


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="aiattr", description=__doc__)
    ap.add_argument("--config", help="path to config.yaml (default: ./config.yaml)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init-db", help="create tables and views")
    sub.add_parser("ingest", help="read commits and authorship logs from every repo")
    sub.add_parser("survival", help="take a survival snapshot of every repo")
    imp = sub.add_parser("import", help="load SCM and delivery events from JSONL")
    imp.add_argument("--prs")
    imp.add_argument("--deployments")
    imp.add_argument("--incidents")
    imp.add_argument("--generated")
    sub.add_parser("link-deploys", help="stamp commits with their first production deploy")
    sub.add_parser("run", help="ingest, link deploys and take survival snapshots")
    rep = sub.add_parser("report", help="print the metrics as JSON")
    rep.add_argument("--team")
    rep.add_argument("--days", type=int, default=90)
    cp = sub.add_parser("copy-db", help="copy all data into another database, e.g. SQLite to Postgres")
    cp.add_argument("--to", required=True, help="destination URL (must be empty)")
    srv = sub.add_parser("serve", help="start the API and dashboard")
    srv.add_argument("--host", default="127.0.0.1")
    srv.add_argument("--port", type=int, default=8000)
    args = ap.parse_args(argv)

    cfg = config.load(args.config)
    if args.cmd == "serve":
        import os
        import uvicorn
        os.environ["DATABASE_URL"] = cfg["database_url"]
        uvicorn.run("aiattr.api:app", host=args.host, port=args.port)
        return

    with config.connect(cfg) as conn:
        if args.cmd == "init-db":
            config.init_db(conn)
            print("schema ready")
        if args.cmd in ("ingest", "run"):
            for repo in cfg["repos"]:
                print(json.dumps(ingest.ingest_repo(conn, repo, cfg["author_salt"])))
        if args.cmd == "import":
            if args.prs:
                print("pull requests:", imports.import_prs(conn, args.prs, cfg["author_salt"]))
            if args.deployments:
                print("deployments:", imports.import_deployments(conn, args.deployments))
            if args.incidents:
                print("incidents:", imports.import_incidents(conn, args.incidents))
            if args.generated:
                print("agent telemetry rows:", imports.import_generated(conn, args.generated))
        if args.cmd in ("link-deploys", "run", "import"):
            for repo in cfg["repos"]:
                n = ingest.link_deployments(conn, repo, cfg["production_environment"])
                print(f"{repo['name']}: {n} commits stamped with a production deploy")
        if args.cmd in ("survival", "run"):
            for repo in cfg["repos"]:
                print(json.dumps(survival.take_snapshot(conn, repo)))
        if args.cmd == "copy-db":
            with db.connect(args.to) as dst:
                for table, n in db.copy_database(conn, dst).items():
                    print(f"{table}: {n} rows")
            print("Copied. Point database_url at the new database to switch over.")
        if args.cmd == "report":
            print(json.dumps(metrics.dashboard(conn, args.team, args.days), indent=2, default=str))


if __name__ == "__main__":
    main()
