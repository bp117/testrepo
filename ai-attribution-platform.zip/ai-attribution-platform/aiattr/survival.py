"""Survival snapshots: which lines on the default branch today came from where.

One snapshot blames every text file at the default branch head, maps each
surviving line back to the commit that introduced it, and classifies it with
that commit's authorship log.
"""
from __future__ import annotations

from . import db, gitutil


def take_snapshot(conn, cfg: dict) -> dict:
    path = cfg["path"]
    row = conn.execute("SELECT id FROM repos WHERE name = %s", (cfg["name"],)).fetchone()
    if not row:
        raise RuntimeError(f"repo {cfg['name']} has not been ingested yet")
    repo_id = row[0]
    head = gitutil.resolve_default(path, cfg.get("default_branch", "main"))

    ranges: dict[tuple[str, str], list] = {}
    for sha, file, start, end, kind, tool, model in conn.execute(
            """SELECT sha, file, start_line, end_line, kind, tool, model
               FROM attribution_ranges WHERE repo_id = %s""", (repo_id,)):
        ranges.setdefault((sha, file), []).append((start, end, kind, tool, model))
    noted = {r[0] for r in conn.execute(
        "SELECT sha FROM commits WHERE repo_id = %s AND has_note", (repo_id,))}

    counts: dict[tuple[str, str, str, str], int] = {}
    files = gitutil.text_files(path, head)
    for f in files:
        for sha, origin_file, origin_line in gitutil.blame_origins(path, head, f):
            key = (sha, "untracked" if sha in noted else "no_note", "", "")
            for start, end, kind, tool, model in ranges.get((sha, origin_file), ()):
                if start <= origin_line <= end:
                    key = (sha, kind, tool, model)
                    break
            counts[key] = counts.get(key, 0) + 1

    snap_id = conn.execute(
        "INSERT INTO survival_snapshots (repo_id, head_sha, taken_at) VALUES (%s, %s, %s) RETURNING id",
        (repo_id, head, conn.ts(db.now()))).fetchone()[0]
    for (sha, kind, tool, model), n in counts.items():
        conn.execute("INSERT INTO line_survival VALUES (%s, %s, %s, %s, %s, %s)",
                     (snap_id, sha, kind, tool, model, n))
    conn.commit()
    return {"repo": cfg["name"], "snapshot_id": snap_id, "files": len(files),
            "lines": sum(counts.values())}
