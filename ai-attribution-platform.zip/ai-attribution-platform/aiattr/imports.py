"""Import pull requests, deployments, incidents and agent telemetry from JSONL.

One JSON object per line. Every record names its repo by the `name` used in
the config file. See the README for how to produce these files from your SCM,
pipeline and incident tools.
"""
from __future__ import annotations

import json

from .ingest import author_hash


def _records(path: str):
    with open(path, encoding="utf-8") as fh:
        for n, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{n}: not valid JSON ({exc})") from exc


def _repo_ids(conn) -> dict[str, int]:
    return dict(conn.execute("SELECT name, id FROM repos").fetchall())


def import_prs(conn, path: str, salt: str) -> int:
    repos, n = _repo_ids(conn), 0
    for r in _records(path):
        repo_id = repos.get(r["repo"])
        if repo_id is None:
            continue
        conn.execute(
            """INSERT INTO pull_requests (repo_id, number, author_hash, created_at,
                   first_review_at, merged_at, merge_commit_sha, state)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
               ON CONFLICT (repo_id, number) DO UPDATE SET
                   first_review_at = EXCLUDED.first_review_at,
                   merged_at = EXCLUDED.merged_at,
                   merge_commit_sha = EXCLUDED.merge_commit_sha,
                   state = EXCLUDED.state""",
            (repo_id, r["number"], author_hash(r.get("author"), salt), conn.ts(r["created_at"]),
             conn.ts(r.get("first_review_at")), conn.ts(r.get("merged_at")), r.get("merge_commit_sha"),
             r.get("state", "merged" if r.get("merged_at") else "open")))
        conn.execute("DELETE FROM pr_commits WHERE repo_id = %s AND number = %s",
                     (repo_id, r["number"]))
        for sha in r.get("commits") or []:
            conn.execute("INSERT INTO pr_commits VALUES (%s, %s, %s) ON CONFLICT DO NOTHING",
                         (repo_id, r["number"], sha))
        n += 1
    conn.commit()
    return n


def import_deployments(conn, path: str) -> int:
    repos, n = _repo_ids(conn), 0
    for r in _records(path):
        repo_id = repos.get(r["repo"])
        if repo_id is None:
            continue
        conn.execute(
            "INSERT INTO deployments VALUES (%s, %s, %s, %s, %s) ON CONFLICT DO NOTHING",
            (repo_id, r["sha"], r.get("environment", "production"), conn.ts(r["deployed_at"]),
             r.get("status", "success")))
        n += 1
    conn.commit()
    return n


def import_incidents(conn, path: str) -> int:
    repos, n = _repo_ids(conn), 0
    for r in _records(path):
        repo_id = repos.get(r["repo"])
        if repo_id is None:
            continue
        conn.execute(
            """INSERT INTO incidents VALUES (%s, %s, %s, %s, %s)
               ON CONFLICT (repo_id, ref) DO UPDATE SET caused_by_sha = EXCLUDED.caused_by_sha""",
            (repo_id, str(r["ref"]), r.get("kind", "incident"), r["caused_by_sha"], conn.ts(r["opened_at"])))
        n += 1
    conn.commit()
    return n


def import_generated(conn, path: str) -> int:
    repos, n = _repo_ids(conn), 0
    for r in _records(path):
        repo_id = repos.get(r["repo"])
        if repo_id is None:
            continue
        conn.execute(
            """INSERT INTO agent_generated VALUES (%s, %s, %s, %s, %s)
               ON CONFLICT (repo_id, day, tool, model)
               DO UPDATE SET generated_lines = EXCLUDED.generated_lines""",
            (repo_id, str(r["day"])[:10], r["tool"], r.get("model", ""), r["generated_lines"]))
        n += 1
    conn.commit()
    return n
