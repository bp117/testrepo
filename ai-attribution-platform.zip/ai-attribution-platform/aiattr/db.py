"""One small database layer for both backends.

    postgresql://user:pass@host:5432/dbname     needs psycopg
    sqlite:///relative/or//absolute/path.db     standard library only

Every query in the package is written once, in SQL both engines accept, with
psycopg-style placeholders (%s and %(name)s). For SQLite the placeholders are
rewritten on the way in. Timestamps are normalised to UTC: real timestamptz
values in Postgres, fixed-format ISO text in SQLite so they sort correctly.
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = Path(__file__).resolve().parent.parent / "schema.sql"
_PLACEHOLDER = re.compile(r"%\((\w+)\)s|%s|%%")

# Copy order respects foreign keys.
TABLES = ["repos", "commits", "commit_attribution", "attribution_ranges", "note_sessions",
          "survival_snapshots", "line_survival", "pull_requests", "pr_commits",
          "deployments", "incidents", "agent_generated"]
BOOL_COLUMNS = {"commits": ("is_merge", "on_default", "has_note")}
SERIAL_TABLES = ("repos", "survival_snapshots")


def to_utc(value) -> datetime | None:
    """Accept a datetime or an ISO 8601 string; return an aware UTC datetime."""
    if value is None or value == "":
        return None
    if isinstance(value, str):
        value = datetime.fromisoformat(value.strip().replace("Z", "+00:00").replace(" ", "T", 1))
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


class _Result:
    def __init__(self, cur):
        self._cur = cur
        self.rowcount = cur.rowcount
        desc = cur.description or []
        self.columns = [d[0] for d in desc]

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()

    def __iter__(self):
        return iter(self._cur.fetchall())


class DB:
    def __init__(self, url: str):
        self.url = url
        if url.startswith("sqlite:"):
            self.dialect = "sqlite"
            # sqlite:///relative.db   sqlite:////absolute/path.db   sqlite:///~/in-home.db
            path = url[len("sqlite:"):]
            path = path[3:] if path.startswith("///") else path.lstrip("/")
            if not path or path == ":memory:":
                path = ":memory:"
            else:
                path = str(Path(path).expanduser())
                Path(path).parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(path)
            self._conn.execute("PRAGMA foreign_keys = ON")
            self._conn.execute("PRAGMA journal_mode = WAL")
        elif url.startswith(("postgresql:", "postgres:")):
            self.dialect = "postgres"
            try:
                import psycopg
            except ImportError as exc:  # pragma: no cover
                raise SystemExit("Postgres needs psycopg: pip install 'psycopg[binary]'") from exc
            self._conn = psycopg.connect(url)
        else:
            raise SystemExit(f"unsupported database_url: {url!r} (use sqlite:/// or postgresql://)")

    # -- queries ---------------------------------------------------------
    def _translate(self, sql: str, named: bool) -> str:
        if self.dialect == "postgres":
            return sql

        def repl(m):
            if m.group(0) == "%%":
                return "%"
            return f":{m.group(1)}" if m.group(1) else "?"
        return _PLACEHOLDER.sub(repl, sql)

    def execute(self, sql: str, params=None) -> _Result:
        if params is None:
            if self.dialect == "postgres":
                return _Result(self._conn.execute(sql))
            return _Result(self._conn.execute(self._translate(sql, False)))
        return _Result(self._conn.execute(self._translate(sql, isinstance(params, dict)), params))

    def script(self, sql: str) -> None:
        if self.dialect == "sqlite":
            self._conn.executescript(sql)
        else:
            self._conn.execute(sql)

    def in_chunks(self, sql: str, prefix: tuple, values: list, size: int = 400) -> int:
        """Run `sql` once per chunk of values. `sql` contains `{in}` where the
        placeholder list goes; `prefix` holds the parameters that come first."""
        total = 0
        for i in range(0, len(values), size):
            chunk = values[i:i + size]
            marks = ", ".join(["%s"] * len(chunk))
            total += max(self.execute(sql.replace("{in}", marks), (*prefix, *chunk)).rowcount, 0)
        return total

    # -- values ----------------------------------------------------------
    def ts(self, value):
        """Timestamp parameter in this backend's storage form."""
        dt = to_utc(value)
        if dt is None:
            return None
        return dt if self.dialect == "postgres" else dt.isoformat(timespec="seconds")

    @staticmethod
    def dt(value) -> datetime | None:
        """Timestamp read back from either backend, as an aware UTC datetime."""
        return to_utc(value)

    # -- lifecycle -------------------------------------------------------
    def init_schema(self) -> None:
        sql = SCHEMA.read_text(encoding="utf-8")
        if self.dialect == "sqlite":
            sql = sql.replace("{{PK}}", "INTEGER PRIMARY KEY AUTOINCREMENT").replace("{{TS}}", "TEXT")
        else:
            sql = sql.replace("{{PK}}", "serial PRIMARY KEY").replace("{{TS}}", "timestamptz")
        self.script(sql)
        self.commit()

    def commit(self) -> None:
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *_):
        if exc_type is None:
            self._conn.commit()
        else:
            self._conn.rollback()
        self._conn.close()


def connect(url: str) -> DB:
    return DB(url)


def copy_database(src: DB, dst: DB) -> dict[str, int]:
    """Copy every table from one backend to the other (for example SQLite to
    Postgres once it is provisioned). The destination must be empty."""
    dst.init_schema()
    if dst.execute("SELECT count(*) FROM repos").fetchone()[0]:
        raise SystemExit("destination already has data; refusing to copy into it")
    counts = {}
    for table in TABLES:
        res = src.execute(f"SELECT * FROM {table}")
        cols = res.columns
        bools = [cols.index(c) for c in BOOL_COLUMNS.get(table, ()) if c in cols]
        marks = ", ".join(["%s"] * len(cols))
        n = 0
        for row in res.fetchall():
            row = list(row)
            for i in bools:
                row[i] = bool(row[i])
            for i, c in enumerate(cols):
                if c.endswith("_at") and row[i] is not None:
                    row[i] = dst.ts(row[i])
                elif c == "day" and row[i] is not None:
                    row[i] = str(row[i])
            dst.execute(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({marks})", row)
            n += 1
        counts[table] = n
    if dst.dialect == "postgres":
        for table in SERIAL_TABLES:
            dst.execute(f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), "
                        f"COALESCE((SELECT max(id) FROM {table}), 1))")
    dst.commit()
    return counts
