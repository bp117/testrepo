"""hartford: track AI-written code in git.

  hartford install            set up git hooks and agent hooks for this user
  hartford init [--agent-hooks]  set up hooks in the current repo only
  hartford checkpoint ...     record who changed the working tree (called by agent hooks)
  hartford status             show attribution waiting for the next commit
  hartford stats [rev|a..b]   AI vs human line counts (add --json)
  hartford blame <file>       git blame with the agent shown for AI lines
  hartford show [rev]         print a commit's authorship log
  hartford sync [remote]      fetch, merge and push refs/notes/ai
  hartford remap <new> <old>… rebuild a log after a server-side squash or rebase
  hartford log                show recent hook activity
  hartford doctor             check the setup and test the agent hook end to end
  hartford uninstall          remove everything `install` added
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import traceback
from datetime import datetime
from pathlib import Path

from . import __version__, core

HOOKS = ("post-commit", "post-rewrite", "pre-push", "post-merge")
MARK = "# hartford-cli"
EDIT_MATCHER = "Edit|Write|MultiEdit|NotebookEdit"


def _py() -> str:
    # forward slashes work in sh, cmd and PowerShell on Windows
    return sys.executable.replace("\\", "/") if os.name == "nt" else sys.executable


def _self_cmd() -> str:
    """Command for sh and cmd. Double quotes survive both; GUI git clients
    and agents often run hooks with a bare PATH, so the path is absolute."""
    return f'"{_py()}" -m hartford_cli'


def _ps_cmd() -> str:
    """The same command for PowerShell, which needs the call operator."""
    return "& '" + sys.executable.replace("'", "''") + "' -m hartford_cli"


def _log_path() -> Path:
    return _home() / ".hartford" / "hook.log"


def log(msg: str) -> None:
    """Append one line to ~/.hartford/hook.log. Never raises."""
    try:
        path = _log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and path.stat().st_size > 1_000_000:
            path.replace(path.with_name("hook.log.1"))
        with path.open("a", encoding="utf-8") as fh:
            fh.write(f"{datetime.now().isoformat(timespec='seconds')} {msg}\n")
    except OSError:
        pass


def _home() -> Path:
    return Path(os.environ.get("HARTFORD_HOME") or Path.home())


# ------------------------------------------------------------ git hooks

def _hook_script(name: str, chain_local: bool) -> str:
    cmd = _self_cmd()
    lines = ["#!/bin/sh", f"{MARK} managed hook: {name}. Never blocks git."]
    if name == "post-rewrite":
        lines += ['input=$(cat)',
                  f'printf \'%s\\n\' "$input" | {cmd} hook {name} "$@" >/dev/null 2>&1 || true']
        relay = 'printf \'%s\\n\' "$input" | '
    else:
        lines += [f'{cmd} hook {name} "$@" </dev/null >/dev/null 2>&1 || true']
        relay = ""
    if chain_local:
        lines += ['local_hook="$(git rev-parse --git-dir 2>/dev/null)/hooks/' + name + '"',
                  f'if [ -x "$local_hook" ] && ! grep -q "{MARK}" "$local_hook" 2>/dev/null; then',
                  f'  {relay}"$local_hook" "$@" || exit $?',
                  'fi']
    return "\n".join(lines) + "\n"


def _write_exec(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def install_global_git_hooks() -> str:
    current = core.git("config", "--global", "--get", "core.hooksPath", check=False).strip()
    target = _home() / ".hartford" / "hooks"
    if current and Path(current).expanduser() != target:
        return (f"skipped git hooks: core.hooksPath is already set to {current}. "
                "Run `hartford init` inside each repo instead.")
    for name in HOOKS:
        _write_exec(target / name, _hook_script(name, chain_local=True))
    core.git("config", "--global", "core.hooksPath", str(target))
    return f"git hooks installed in {target} (global core.hooksPath)"


def init_repo_hooks(root: str) -> str:
    local = core.git("config", "--local", "--get", "core.hooksPath", cwd=root, check=False).strip()
    global_hp = core.git("config", "--global", "--get", "core.hooksPath", check=False).strip()
    if not local and global_hp and Path(global_hp).expanduser() == _home() / ".hartford" / "hooks":
        return "git hooks: the global hartford hooks already cover this repo"
    hooks_dir = (Path(root) / local) if local else core.git_dir(root) / "hooks"
    cmd = _self_cmd()
    for name in HOOKS:
        path = hooks_dir / name
        existing = path.read_text() if path.exists() else ""
        if MARK in existing:
            continue
        if name == "post-rewrite":
            if existing:
                # an existing hook reads stdin; do not fight it for the input
                return (f"{path} already exists and reads stdin. Add this line to it by hand:\n"
                        f"  {cmd} hook post-rewrite \"$@\"")
            call = f'{cmd} hook {name} "$@" >/dev/null 2>&1 || true'
        else:
            call = f'{cmd} hook {name} "$@" </dev/null >/dev/null 2>&1 || true'
        body = existing if existing else "#!/bin/sh\n"
        _write_exec(path, body.rstrip("\n") + f"\n{MARK}\n{call}\n")
    return f"git hooks installed in {hooks_dir}"


def uninstall_git_hooks() -> str:
    target = _home() / ".hartford" / "hooks"
    current = core.git("config", "--global", "--get", "core.hooksPath", check=False).strip()
    if current and Path(current).expanduser() == target:
        core.git("config", "--global", "--unset", "core.hooksPath", check=False)
    for name in HOOKS:
        (target / name).unlink(missing_ok=True)
    return "global git hooks removed"


# ----------------------------------------------------------- agent hooks

def _load_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def copilot_hook_entry() -> dict:
    args = "checkpoint copilot --hook"
    return {"type": "command",
            "command": f"{_self_cmd()} {args}",
            "bash": f"{_self_cmd()} {args}",
            "powershell": f"{_ps_cmd()} {args}",
            "timeoutSec": 30}


def install_copilot() -> str:
    """User-level Copilot hooks, shared by the Copilot CLI, app and VS Code agent."""
    path = _home() / ".copilot" / "hooks" / "hartford.json"
    entry = copilot_hook_entry()
    _save_json(path, {"version": 1, "hooks": {"PreToolUse": [entry], "PostToolUse": [entry]}})
    return f"Copilot hooks written to {path}"


def install_workspace_hook(root: str) -> str:
    """Copilot hook inside the repo, at .github/hooks/hartford.json. VS Code reads
    this location in every harness, unlike the user-level file. It holds this
    machine's Python path, so it is kept out of git via .git/info/exclude."""
    rel = ".github/hooks/hartford.json"
    entry = copilot_hook_entry()
    _save_json(Path(root) / rel, {"version": 1, "hooks": {"PreToolUse": [entry], "PostToolUse": [entry]}})
    exclude = core.git_dir(root) / "info" / "exclude"
    exclude.parent.mkdir(parents=True, exist_ok=True)
    current = exclude.read_text() if exclude.exists() else ""
    if rel not in current.splitlines():
        exclude.write_text(current.rstrip("\n") + ("\n" if current else "") + rel + "\n")
    return f"Copilot hook written to {Path(root) / rel} (kept out of git via .git/info/exclude)"


def install_claude() -> str:
    path = _home() / ".claude" / "settings.json"
    data = _load_json(path)
    cmd = f"{_self_cmd()} checkpoint claude --hook"
    hooks = data.setdefault("hooks", {})
    for event in ("PreToolUse", "PostToolUse"):
        entries = [e for e in hooks.get(event, []) if MARK not in json.dumps(e)]
        entries.append({"matcher": EDIT_MATCHER,
                        "hooks": [{"type": "command", "command": f"{cmd} {MARK}"}]})
        hooks[event] = entries
    _save_json(path, data)
    return f"Claude Code hooks merged into {path}"


def uninstall_agents() -> str:
    (_home() / ".copilot" / "hooks" / "hartford.json").unlink(missing_ok=True)
    path = _home() / ".claude" / "settings.json"
    data = _load_json(path)
    if "hooks" in data:
        for event in list(data["hooks"]):
            data["hooks"][event] = [e for e in data["hooks"][event] if MARK not in json.dumps(e)]
            if not data["hooks"][event]:
                del data["hooks"][event]
        _save_json(path, data)
    return "agent hooks removed"


# ------------------------------------------------------------- commands

def _root_or_exit(cwd: str | None = None) -> str:
    root = core.repo_root(cwd)
    if not root:
        raise SystemExit("not inside a git repository")
    return root


SINGLE_PATH_KEYS = {"file_path", "filepath", "path", "fspath", "target_file", "filename"}
MULTI_PATH_KEYS = {"files", "filepaths", "file_paths"}
TERMINAL_TOOLS = {"run_in_terminal", "bash", "shell", "powershell"}
EDIT_TOOLS = {"write", "edit", "multiedit", "notebookedit", "applypatch", "apply_patch",
              "copilot_insertedit", "copilot_replacestring", "vscode_editfile_internal",
              "create_file", "create", "delete_file", "rename_file", "move_file",
              "replace_string_in_file", "multi_replace_string_in_file", "insert_edit_into_file",
              "str_replace", "str_replace_editor", "insert", "edit_notebook_file"}
READ_ONLY_WORDS = ("find", "search", "read", "grep", "glob", "list", "ls", "fetch", "web",
                   "open", "todo", "view", "get_", "semantic", "usages", "problems")


def classify_tool(name: str) -> str:
    """'terminal', 'edit', 'skip', or 'unknown' when the payload names no tool."""
    lower = (name or "").lower()
    if not lower:
        return "unknown"
    if lower in TERMINAL_TOOLS:
        return "terminal"
    if lower in EDIT_TOOLS:
        return "edit"
    if any(w in lower for w in READ_ONLY_WORDS):
        return "skip"
    if any(w in lower for w in ("edit", "write", "replace", "patch", "create", "insert")):
        return "edit"
    return "skip"


def _paths_in(value) -> list[str]:
    """File paths named in a tool's input or result, whatever the key is called."""
    found: list[str] = []
    if isinstance(value, dict):
        for k, v in value.items():
            kl = k.lower()
            if kl in SINGLE_PATH_KEYS and isinstance(v, str):
                found.append(v)
            elif kl in MULTI_PATH_KEYS:
                if isinstance(v, str):
                    found.append(v)
                elif isinstance(v, list):
                    found.extend(x for x in v if isinstance(x, str))
            if isinstance(v, (dict, list)):
                found.extend(_paths_in(v))
    elif isinstance(value, list):
        for v in value:
            found.extend(_paths_in(v))
    return found


def _abs(raw: str, cwd: str | None) -> Path:
    raw = raw.strip()
    for prefix in ("file://localhost", "file://"):
        if raw.startswith(prefix):
            raw = raw[len(prefix):]
            if os.name == "nt" and raw.startswith("/") and len(raw) > 2 and raw[2] == ":":
                raw = raw[1:]
            break
    p = Path(raw).expanduser()
    if not p.is_absolute() and cwd:
        p = Path(cwd) / p
    return p


def _rel(root: str, p: Path) -> str | None:
    try:
        rel = os.path.relpath(os.path.realpath(p), os.path.realpath(root))
    except ValueError:  # different drive on Windows
        return None
    if rel.startswith(".."):
        return None
    return rel.replace("\\", "/")


def _tool_paths(payload: dict) -> list[str]:
    raw = []
    for k in ("tool_input", "toolInput", "toolArgs", "tool_response", "toolResponse",
              "tool_result", "toolResult"):
        v = payload.get(k)
        if isinstance(v, str):
            try:
                v = json.loads(v)
            except json.JSONDecodeError:
                continue
        raw.extend(_paths_in(v))
    return raw


def _find_root(payload: dict) -> str | None:
    for cand in [payload.get("cwd")] + _tool_paths(payload):
        if not cand:
            continue
        p = Path(str(cand)).expanduser()
        if not p.is_absolute() and payload.get("cwd"):
            p = Path(str(payload["cwd"])) / p
        d = p if p.is_dir() else p.parent
        if d.exists():
            root = core.repo_root(str(d))
            if root:
                return root
    return core.repo_root()


def cmd_checkpoint(args) -> int:
    payload: dict = {}
    if args.hook:
        try:
            raw = sys.stdin.read()
            payload = json.loads(raw) if raw.strip() else {}
        except (json.JSONDecodeError, OSError, UnicodeDecodeError) as exc:
            log(f"{args.agent} bad payload: {exc}")
            payload = {}
    event = str(payload.get("hook_event_name") or payload.get("hookEventName") or "")
    conv = (args.session or payload.get("session_id") or payload.get("chat_session_id")
            or payload.get("sessionId") or os.environ.get("HARTFORD_SESSION") or "unknown")
    tool = payload.get("tool_name") or payload.get("toolName") or ""
    where = f"agent={args.agent} event={event or '-'} tool={tool or '-'} session={conv}"
    # Hooks must never break the agent: any failure exits 0, and is logged.
    try:
        root = _find_root(payload) if args.hook else core.repo_root()
        if not root:
            log(f"{where} SKIP not in a git repo (payload cwd={payload.get('cwd')!r}, "
                f"process cwd={os.getcwd()!r})")
            if not args.hook:
                raise SystemExit("not inside a git repository")
            return 0
        before = args.before or event.lower() == "pretooluse"
        kind = classify_tool(str(tool)) if args.hook else "unknown"
        if kind == "skip":
            log(f"{where} skip: not an editing tool")
            return 0
        paths = None
        if kind == "edit":
            cwd = payload.get("cwd")
            rels = [_rel(root, _abs(p, cwd)) for p in _tool_paths(payload)]
            paths = sorted({r for r in rels if r}) or None   # None: fall back to all files
        contents = None
        dirty = payload.get("dirty_files") or payload.get("dirtyFiles")
        if isinstance(dirty, dict):
            contents = {}
            for k, v in dirty.items():
                r = _rel(root, _abs(k, payload.get("cwd")))
                if r and isinstance(v, str):
                    contents[r] = v
        scope = ", ".join(paths) if paths else "all changed files"
        if args.agent == "human" or before:
            if kind == "edit" and str(tool).lower() in ("create_file", "create") and paths:
                paths = [p for p in paths if (Path(root) / p).exists()]
            touched = core.checkpoint(root, None, paths=paths, contents=contents) if paths != [] else {}
            n = sum(touched.values())
            log(f"{where} repo={root} pre-edit checkpoint on {scope}: "
                + (f"{n} lines changed since the last checkpoint marked human ({', '.join(sorted(touched))})"
                   if n else "nothing new"))
            return 0
        model = (args.model or payload.get("model") or os.environ.get("HARTFORD_MODEL")
                 or "unknown")
        sid = core.session_id(args.agent, str(conv))
        email = core.git("config", "user.email", cwd=root, check=False).strip()
        record = {"agent_id": {"tool": args.agent, "id": str(conv), "model": str(model)}}
        if email:
            record["human_author"] = email
        touched = core.checkpoint(root, f"{sid}::{core.trace_id()}", (sid, record), paths=paths,
                                  contents=contents, wait_seconds=2.0 if args.hook else 0.0)
        log(f"{where} repo={root} tagged {sum(touched.values())} lines in {len(touched)} files"
            + (f": {', '.join(sorted(touched))}" if touched else " (no file changed since the last checkpoint)"))
        if not args.hook:
            for path, n in touched.items():
                print(f"{path}: {n} lines attributed to {args.agent}")
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001
        log(f"{where} ERROR " + traceback.format_exc().replace("\n", " | "))
        if not args.hook:
            raise
    return 0


def cmd_hook(args) -> int:
    try:
        root = core.repo_root()
        if not root:
            return 0
        if args.name == "post-commit":
            sha = core.post_commit(root)
            if sha:
                s = core.commit_stats(root, sha)
                log(f"post-commit repo={root} {sha[:10]} note written: {s['ai_additions']} AI of "
                    f"{s['git_diff_added_lines']} added lines")
        elif args.name == "post-rewrite":
            pairs = [tuple(ln.split()[:2]) for ln in sys.stdin.read().splitlines()
                     if len(ln.split()) >= 2]
            core.post_rewrite(root, pairs)
        elif args.name in ("pre-push", "post-merge"):
            if os.environ.get("HARTFORD_PUSHING"):
                return 0
            auto = core.git("config", "--get", "hartford.autoSyncNotes", cwd=root, check=False).strip()
            if auto.lower() == "false":
                return 0
            remote = args.rest[0] if (args.name == "pre-push" and args.rest) else "origin"
            core.sync_notes(root, remote, push=args.name == "pre-push", timeout=20)
    except Exception:  # noqa: BLE001  hooks never fail a git command
        log(f"git-hook {args.name} ERROR " + traceback.format_exc().replace("\n", " | "))
    return 0


def cmd_status(args) -> int:
    root = _root_or_exit()
    state = core.load_state(root)
    rows = []
    for path, entry in sorted(state["files"].items()):
        by_tool: dict[str, int] = {}
        for key in entry["keys"]:
            if key:
                tool = (state["sessions"].get(key.split("::", 1)[0], {}).get("agent_id") or {}).get("tool", "?")
                by_tool[tool] = by_tool.get(tool, 0) + 1
        if by_tool:
            rows.append((path, by_tool))
    if not rows:
        print("No AI attribution waiting for the next commit.")
        return 0
    print("AI-attributed lines in the working tree:")
    for path, by_tool in rows:
        print(f"  {path}: " + ", ".join(f"{n} by {t}" for t, n in sorted(by_tool.items())))
    return 0


def cmd_stats(args) -> int:
    root = _root_or_exit()
    s = core.range_stats(root, args.rev)
    if args.json:
        out = {k: v for k, v in s.items() if k != "commits"}
        print(json.dumps(out, indent=2))
        return 0
    total = s["git_diff_added_lines"]
    pct = (lambda n: f"{100 * n / total:.0f}%") if total else (lambda n: "-")
    print(f"{s['commits']} commit(s), {total} lines added, {s['git_diff_deleted_lines']} deleted")
    print(f"  AI            {s['ai_additions']:>7}  {pct(s['ai_additions'])}")
    print(f"  known human   {s['human_additions']:>7}  {pct(s['human_additions'])}")
    print(f"  unattributed  {s['unknown_additions']:>7}  {pct(s['unknown_additions'])}")
    for tm, b in sorted(s["tool_model_breakdown"].items(), key=lambda kv: -kv[1]["ai_additions"]):
        print(f"    {tm}: {b['ai_additions']}")
    return 0


def cmd_blame(args) -> int:
    root = _root_or_exit()
    rel = os.path.relpath(os.path.abspath(args.file), root)
    for sha, who, n, text in core.blame(root, rel, args.rev):
        print(f"{sha} {who[:18]:<18} {n:>5}) {text}")
    return 0


def cmd_show(args) -> int:
    root = _root_or_exit()
    sha = core.git("rev-parse", "--verify", args.rev + "^{commit}", cwd=root).strip()
    text = core.read_note(root, sha)
    if text is None:
        print(f"no authorship log on {sha[:10]}")
        return 1
    sys.stdout.write(text)
    return 0


def _ok(passed: bool, good: str, bad: str) -> bool:
    print(("  ok    " if passed else "  FAIL  ") + (good if passed else bad))
    return passed


def _has_mark(path: Path) -> bool:
    try:
        return MARK in path.read_text()
    except OSError:
        return False


def cmd_doctor(args) -> int:
    print(f"hartford-cli {__version__}  python: {sys.executable}  hook log: {_log_path()}")
    good = True

    print("Git")
    good &= _ok(bool(shutil.which("git")), "git is on PATH", "git is not on PATH")
    root = core.repo_root()
    local_hp = core.git("config", "--local", "--get", "core.hooksPath", cwd=root,
                        check=False).strip() if root else ""
    global_hp = core.git("config", "--global", "--get", "core.hooksPath", check=False).strip()
    if local_hp:
        hp = Path(root) / local_hp
        good &= _ok(_has_mark(hp / "post-commit"), f"this repo's hooks ({hp}) call hartford",
                    f"this repo sets core.hooksPath={local_hp}, which overrides the global hooks. "
                    "Run `hartford init` here.")
    else:
        hp = Path(global_hp).expanduser() if global_hp else None
        good &= _ok(bool(hp) and _has_mark(hp / "post-commit"), f"global git hooks in {hp}",
                    "global git hooks not installed. Run `hartford install`.")
        if root and not hp:
            good &= _ok(_has_mark(core.git_dir(root) / "hooks" / "post-commit"),
                        "this repo's .git/hooks call hartford", "no hooks in this repo either")
    if root:
        print(f"  info  current repo: {root}")

    print("Copilot agent hook")
    hook_file = _home() / ".copilot" / "hooks" / "hartford.json"
    data = _load_json(hook_file)
    entries = (data.get("hooks") or {}).get("PostToolUse") or []
    good &= _ok(bool(entries), f"hook file {hook_file}",
                f"hook file missing or invalid: {hook_file}. Run `hartford install`.")
    if entries:
        good &= _ok(entries[0] == copilot_hook_entry(), "hook command points at this install",
                    "hook command is from another install. Run `hartford install` again.")
        good &= self_test(entries[0])

    print("Has an agent ever called the hook on this machine?")
    try:
        lines = [ln for ln in _log_path().read_text(encoding="utf-8").splitlines()
                 if "session=doctor-" not in ln]
    except OSError:
        lines = []
    calls = [ln for ln in lines if " agent=" in ln]
    if calls:
        print(f"  ok    {len(calls)} agent hook calls logged. Most recent:")
        for ln in lines[-8:]:
            print("        " + ln)
    else:
        good = False
        print("  FAIL  no agent hook call has ever been logged. The hook works when run directly")
        print("        (see the self-test), so the agent is not calling it. In VS Code check that:")
        print("        - the chat Session Target is Copilot and you are in Agent mode, not Ask or Edit")
        print("        - Chat: Open Chat Customizations > Hooks lists hartford.json with no warning badge")
        print("        - the folder is trusted, chat.useHooks is not false, and no org ChatHooks policy blocks it")
        print("        - the agent actually edited a file (a reply with code in it is not an edit)")
        print("        If hartford.json is not listed under Hooks, VS Code is not reading ~/.copilot/hooks.")
        print("        Put the hook in the repo instead:  hartford init --agent-hooks")
    return 0 if good else 1


def self_test(entry: dict) -> bool:
    """Run the configured hook command the way an agent would, in a scratch repo."""
    with tempfile.TemporaryDirectory() as td:
        core.git("init", "-q", td)
        Path(td, "probe.py").write_text("print('hello')\n")
        payload = json.dumps({"hook_event_name": "PostToolUse", "session_id": "doctor-self-test",
                              "cwd": td, "tool_name": "create_file",
                              "tool_input": {"filePath": str(Path(td, "probe.py"))}})
        if os.name == "nt":
            argv, shell = ["powershell", "-NoProfile", "-Command", entry.get("powershell", "")], False
        else:
            argv, shell = entry.get("bash") or entry.get("command", ""), True
        try:
            proc = subprocess.run(argv, shell=shell, input=payload, capture_output=True,
                                  text=True, timeout=60, cwd=str(Path.home()))
        except (OSError, subprocess.TimeoutExpired) as exc:
            return _ok(False, "", f"self-test could not run the hook command: {exc}")
        state = core.load_state(td)
        tagged = sum(1 for e in state["files"].values() for k in e["keys"] if k)
        detail = (proc.stderr or proc.stdout).strip().splitlines()[-1:] or [""]
        return _ok(tagged == 1, "self-test: the hook command ran and tagged an AI line",
                   f"self-test: the hook command did not tag anything (exit {proc.returncode}). "
                   f"{detail[0]}  See {_log_path()}")


def cmd_init(args) -> int:
    root = _root_or_exit()
    print(init_repo_hooks(root))
    if args.agent_hooks:
        print(install_workspace_hook(root))
        print("Reload the VS Code window, then check Chat: Open Chat Customizations > Hooks.")
    return 0


def cmd_install(args) -> int:
    agents = [a for a in args.agents.split(",") if a]
    if not args.no_git_hooks:
        print(install_global_git_hooks())
    if "copilot" in agents:
        print(install_copilot())
    if "claude" in agents:
        print(install_claude())
    print("Done. Run `hartford doctor` to check the setup, then commit as usual.")
    return 0


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="hartford", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", action="version", version=f"hartford-cli {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("install")
    p.add_argument("--agents", default="copilot,claude", help="comma list: copilot,claude")
    p.add_argument("--no-git-hooks", action="store_true")
    p.set_defaults(fn=cmd_install)

    p = sub.add_parser("init", help="set up hooks in the current repo")
    p.add_argument("--agent-hooks", action="store_true",
                   help="also write the Copilot hook into this repo's .github/hooks")
    p.set_defaults(fn=cmd_init)

    p = sub.add_parser("uninstall")
    p.set_defaults(fn=lambda a: print(uninstall_git_hooks(), uninstall_agents(), sep="\n") or 0)

    p = sub.add_parser("checkpoint")
    p.add_argument("agent", help="agent name (copilot, claude, cursor, ...) or `human`")
    p.add_argument("--hook", action="store_true", help="read the agent's hook payload from stdin")
    p.add_argument("--before", action="store_true", help="pre-edit checkpoint: changes so far are human")
    p.add_argument("--session")
    p.add_argument("--model")
    p.set_defaults(fn=cmd_checkpoint)

    p = sub.add_parser("hook")
    p.add_argument("name", choices=HOOKS)
    p.add_argument("rest", nargs="*")
    p.set_defaults(fn=cmd_hook)

    sub.add_parser("status").set_defaults(fn=cmd_status)
    sub.add_parser("doctor").set_defaults(fn=cmd_doctor)

    p = sub.add_parser("log", help="show the last lines of the hook log")
    p.add_argument("-n", type=int, default=30)
    p.set_defaults(fn=lambda a: print("\n".join(
        _log_path().read_text(encoding="utf-8").splitlines()[-a.n:]) if _log_path().exists()
        else f"no hook log yet at {_log_path()}") or 0)

    p = sub.add_parser("stats")
    p.add_argument("rev", nargs="?")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_stats)

    p = sub.add_parser("blame")
    p.add_argument("file")
    p.add_argument("rev", nargs="?", default="HEAD")
    p.set_defaults(fn=cmd_blame)

    p = sub.add_parser("show")
    p.add_argument("rev", nargs="?", default="HEAD")
    p.set_defaults(fn=cmd_show)

    p = sub.add_parser("sync")
    p.add_argument("remote", nargs="?", default="origin")
    p.set_defaults(fn=lambda a: print(core.sync_notes(_root_or_exit(), a.remote)) or 0)

    p = sub.add_parser("remap")
    p.add_argument("new")
    p.add_argument("old", nargs="+")
    p.set_defaults(fn=lambda a: 0 if core.remap(
        _root_or_exit(),
        core.git("rev-parse", a.new, cwd=_root_or_exit()).strip(),
        [core.git("rev-parse", o, cwd=_root_or_exit()).strip() for o in a.old]) else 1)

    args = ap.parse_args(argv)
    try:
        raise SystemExit(args.fn(args) or 0)
    except core.GitError as exc:
        raise SystemExit(f"hartford: {exc}")


if __name__ == "__main__":
    main()
